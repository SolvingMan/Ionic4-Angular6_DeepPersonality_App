(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./03thkbgt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/03thkbgt.entry.js",
		"common",
		12
	],
	"./03thkbgt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/03thkbgt.sc.entry.js",
		"common",
		13
	],
	"./1pa4qmzr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1pa4qmzr.entry.js",
		"common",
		14
	],
	"./1pa4qmzr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1pa4qmzr.sc.entry.js",
		"common",
		15
	],
	"./1zw9xxl8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1zw9xxl8.entry.js",
		"common",
		16
	],
	"./1zw9xxl8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1zw9xxl8.sc.entry.js",
		"common",
		17
	],
	"./2jswtbop.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2jswtbop.entry.js",
		18
	],
	"./2jswtbop.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2jswtbop.sc.entry.js",
		19
	],
	"./2pz3wrvd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2pz3wrvd.entry.js",
		"common",
		20
	],
	"./2pz3wrvd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2pz3wrvd.sc.entry.js",
		"common",
		21
	],
	"./3tlbynut.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3tlbynut.entry.js",
		0,
		"common",
		22
	],
	"./3tlbynut.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3tlbynut.sc.entry.js",
		0,
		"common",
		23
	],
	"./6sa0nuni.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6sa0nuni.entry.js",
		0,
		"common",
		24
	],
	"./6sa0nuni.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6sa0nuni.sc.entry.js",
		0,
		"common",
		25
	],
	"./7duttfq4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7duttfq4.entry.js",
		"common",
		26
	],
	"./7duttfq4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7duttfq4.sc.entry.js",
		"common",
		27
	],
	"./7xyknyu2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7xyknyu2.entry.js",
		"common",
		28
	],
	"./7xyknyu2.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7xyknyu2.sc.entry.js",
		"common",
		29
	],
	"./9m4glhzb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9m4glhzb.entry.js",
		"common",
		30
	],
	"./9m4glhzb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9m4glhzb.sc.entry.js",
		"common",
		31
	],
	"./afppgtec.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/afppgtec.entry.js",
		"common",
		32
	],
	"./afppgtec.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/afppgtec.sc.entry.js",
		"common",
		33
	],
	"./aiv0o8np.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aiv0o8np.entry.js",
		"common",
		34
	],
	"./aiv0o8np.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aiv0o8np.sc.entry.js",
		"common",
		35
	],
	"./aq9owtyv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aq9owtyv.entry.js",
		"common",
		36
	],
	"./aq9owtyv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aq9owtyv.sc.entry.js",
		"common",
		37
	],
	"./artgmduf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/artgmduf.entry.js",
		"common",
		38
	],
	"./artgmduf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/artgmduf.sc.entry.js",
		"common",
		39
	],
	"./bixmyxam.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bixmyxam.entry.js",
		"common",
		40
	],
	"./bixmyxam.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bixmyxam.sc.entry.js",
		"common",
		41
	],
	"./bpjzy0mi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bpjzy0mi.entry.js",
		"common",
		42
	],
	"./bpjzy0mi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bpjzy0mi.sc.entry.js",
		"common",
		43
	],
	"./bxbkhzdq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bxbkhzdq.entry.js",
		"common",
		44
	],
	"./bxbkhzdq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bxbkhzdq.sc.entry.js",
		"common",
		45
	],
	"./byrotmou.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/byrotmou.entry.js",
		"common",
		46
	],
	"./byrotmou.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/byrotmou.sc.entry.js",
		"common",
		47
	],
	"./c6noyomn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c6noyomn.entry.js",
		"common",
		48
	],
	"./c6noyomn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c6noyomn.sc.entry.js",
		"common",
		49
	],
	"./cd0mawkq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cd0mawkq.entry.js",
		"common",
		50
	],
	"./cd0mawkq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cd0mawkq.sc.entry.js",
		"common",
		51
	],
	"./cgslbplv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cgslbplv.entry.js",
		"common",
		52
	],
	"./cgslbplv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cgslbplv.sc.entry.js",
		"common",
		53
	],
	"./dctngjqf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dctngjqf.entry.js",
		"common",
		54
	],
	"./dctngjqf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dctngjqf.sc.entry.js",
		"common",
		55
	],
	"./dhkudzxe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dhkudzxe.entry.js",
		"common",
		56
	],
	"./dhkudzxe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dhkudzxe.sc.entry.js",
		"common",
		57
	],
	"./djdzpmir.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/djdzpmir.entry.js",
		"common",
		58
	],
	"./djdzpmir.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/djdzpmir.sc.entry.js",
		"common",
		59
	],
	"./dp5qqko2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dp5qqko2.entry.js",
		"common",
		60
	],
	"./dp5qqko2.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dp5qqko2.sc.entry.js",
		"common",
		61
	],
	"./dsxrjmej.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dsxrjmej.entry.js",
		"common",
		62
	],
	"./dsxrjmej.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dsxrjmej.sc.entry.js",
		"common",
		63
	],
	"./euqpu2rl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/euqpu2rl.entry.js",
		"common",
		64
	],
	"./euqpu2rl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/euqpu2rl.sc.entry.js",
		"common",
		65
	],
	"./fcutox7j.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fcutox7j.entry.js",
		"common",
		66
	],
	"./fcutox7j.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fcutox7j.sc.entry.js",
		"common",
		67
	],
	"./ff74soz5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ff74soz5.entry.js",
		0,
		"common",
		68
	],
	"./ff74soz5.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ff74soz5.sc.entry.js",
		0,
		"common",
		69
	],
	"./flnykrqg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/flnykrqg.entry.js",
		0,
		"common",
		70
	],
	"./flnykrqg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/flnykrqg.sc.entry.js",
		0,
		"common",
		71
	],
	"./fze4h12x.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fze4h12x.entry.js",
		"common",
		72
	],
	"./fze4h12x.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fze4h12x.sc.entry.js",
		"common",
		73
	],
	"./ghycg6lv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ghycg6lv.entry.js",
		0,
		"common",
		74
	],
	"./ghycg6lv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ghycg6lv.sc.entry.js",
		0,
		"common",
		75
	],
	"./gydef8an.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gydef8an.entry.js",
		76
	],
	"./gydef8an.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gydef8an.sc.entry.js",
		77
	],
	"./hbkww4yg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hbkww4yg.entry.js",
		"common",
		78
	],
	"./hbkww4yg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hbkww4yg.sc.entry.js",
		"common",
		79
	],
	"./iengiuxr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iengiuxr.entry.js",
		"common",
		80
	],
	"./iengiuxr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iengiuxr.sc.entry.js",
		"common",
		81
	],
	"./igia2xcg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/igia2xcg.entry.js",
		0,
		"common",
		82
	],
	"./igia2xcg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/igia2xcg.sc.entry.js",
		0,
		"common",
		83
	],
	"./itieadr5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/itieadr5.entry.js",
		"common",
		84
	],
	"./itieadr5.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/itieadr5.sc.entry.js",
		"common",
		85
	],
	"./iz0qeius.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iz0qeius.entry.js",
		"common",
		86
	],
	"./iz0qeius.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iz0qeius.sc.entry.js",
		"common",
		87
	],
	"./ko9xtjhf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ko9xtjhf.entry.js",
		"common",
		88
	],
	"./ko9xtjhf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ko9xtjhf.sc.entry.js",
		"common",
		89
	],
	"./l1qd5s1q.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/l1qd5s1q.entry.js",
		"common",
		90
	],
	"./l1qd5s1q.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/l1qd5s1q.sc.entry.js",
		"common",
		91
	],
	"./liipipwq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/liipipwq.entry.js",
		"common",
		92
	],
	"./liipipwq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/liipipwq.sc.entry.js",
		"common",
		93
	],
	"./lpcdiduj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lpcdiduj.entry.js",
		"common",
		94
	],
	"./lpcdiduj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lpcdiduj.sc.entry.js",
		"common",
		95
	],
	"./m2kc82jl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/m2kc82jl.entry.js",
		"common",
		96
	],
	"./m2kc82jl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/m2kc82jl.sc.entry.js",
		"common",
		97
	],
	"./nk4idtnr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nk4idtnr.entry.js",
		"common",
		98
	],
	"./nk4idtnr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nk4idtnr.sc.entry.js",
		"common",
		99
	],
	"./ntgcdaqn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ntgcdaqn.entry.js",
		0,
		"common",
		100
	],
	"./ntgcdaqn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ntgcdaqn.sc.entry.js",
		0,
		"common",
		101
	],
	"./nww9hskh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nww9hskh.entry.js",
		0,
		"common",
		102
	],
	"./nww9hskh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nww9hskh.sc.entry.js",
		0,
		"common",
		103
	],
	"./oqrzm3wd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oqrzm3wd.entry.js",
		"common",
		104
	],
	"./oqrzm3wd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oqrzm3wd.sc.entry.js",
		"common",
		105
	],
	"./oyn4p6l0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oyn4p6l0.entry.js",
		"common",
		106
	],
	"./oyn4p6l0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oyn4p6l0.sc.entry.js",
		"common",
		107
	],
	"./p3td2uac.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/p3td2uac.entry.js",
		"common",
		108
	],
	"./p3td2uac.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/p3td2uac.sc.entry.js",
		"common",
		109
	],
	"./pfomrf4g.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pfomrf4g.entry.js",
		"common",
		110
	],
	"./pfomrf4g.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pfomrf4g.sc.entry.js",
		"common",
		111
	],
	"./pkzgmgip.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pkzgmgip.entry.js",
		"common",
		112
	],
	"./pkzgmgip.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pkzgmgip.sc.entry.js",
		"common",
		113
	],
	"./pmlspise.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pmlspise.entry.js",
		"common",
		114
	],
	"./pmlspise.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pmlspise.sc.entry.js",
		"common",
		115
	],
	"./qfpjn7jm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qfpjn7jm.entry.js",
		0,
		"common",
		116
	],
	"./qfpjn7jm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qfpjn7jm.sc.entry.js",
		0,
		"common",
		117
	],
	"./r5ond0bc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r5ond0bc.entry.js",
		"common",
		118
	],
	"./r5ond0bc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r5ond0bc.sc.entry.js",
		"common",
		119
	],
	"./rb7kgxl1.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rb7kgxl1.entry.js",
		0,
		"common",
		120
	],
	"./rb7kgxl1.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rb7kgxl1.sc.entry.js",
		0,
		"common",
		121
	],
	"./rnduxbij.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rnduxbij.entry.js",
		"common",
		122
	],
	"./rnduxbij.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rnduxbij.sc.entry.js",
		"common",
		123
	],
	"./sc8lkxg9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sc8lkxg9.entry.js",
		"common",
		124
	],
	"./sc8lkxg9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sc8lkxg9.sc.entry.js",
		"common",
		125
	],
	"./tgsc3cck.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tgsc3cck.entry.js",
		"common",
		126
	],
	"./tgsc3cck.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tgsc3cck.sc.entry.js",
		"common",
		127
	],
	"./titdjovn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/titdjovn.entry.js",
		"common",
		128
	],
	"./titdjovn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/titdjovn.sc.entry.js",
		"common",
		129
	],
	"./tl1ihkeh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tl1ihkeh.entry.js",
		"common",
		130
	],
	"./tl1ihkeh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tl1ihkeh.sc.entry.js",
		"common",
		131
	],
	"./twqqijhh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/twqqijhh.entry.js",
		"common",
		132
	],
	"./twqqijhh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/twqqijhh.sc.entry.js",
		"common",
		133
	],
	"./tzt0ln2a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tzt0ln2a.entry.js",
		0,
		"common",
		134
	],
	"./tzt0ln2a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tzt0ln2a.sc.entry.js",
		0,
		"common",
		135
	],
	"./uocq44rh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uocq44rh.entry.js",
		"common",
		136
	],
	"./uocq44rh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uocq44rh.sc.entry.js",
		"common",
		137
	],
	"./wllrw9yf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wllrw9yf.entry.js",
		0,
		"common",
		138
	],
	"./wllrw9yf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wllrw9yf.sc.entry.js",
		0,
		"common",
		139
	],
	"./wxatjzm0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wxatjzm0.entry.js",
		"common",
		140
	],
	"./wxatjzm0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wxatjzm0.sc.entry.js",
		"common",
		141
	],
	"./xbxudhuf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xbxudhuf.entry.js",
		"common",
		142
	],
	"./xbxudhuf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xbxudhuf.sc.entry.js",
		"common",
		143
	],
	"./xcsewabo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xcsewabo.entry.js",
		144
	],
	"./xcsewabo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xcsewabo.sc.entry.js",
		145
	],
	"./xd08pzte.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xd08pzte.entry.js",
		"common",
		146
	],
	"./xd08pzte.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xd08pzte.sc.entry.js",
		"common",
		147
	],
	"./xj7gdquo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xj7gdquo.entry.js",
		"common",
		148
	],
	"./xj7gdquo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xj7gdquo.sc.entry.js",
		"common",
		149
	],
	"./xvz99xk1.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xvz99xk1.entry.js",
		"common",
		150
	],
	"./xvz99xk1.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xvz99xk1.sc.entry.js",
		"common",
		151
	],
	"./y7e5xxfe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/y7e5xxfe.entry.js",
		"common",
		152
	],
	"./y7e5xxfe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/y7e5xxfe.sc.entry.js",
		"common",
		153
	],
	"./ybvoc4ge.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ybvoc4ge.entry.js",
		"common",
		154
	],
	"./ybvoc4ge.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ybvoc4ge.sc.entry.js",
		"common",
		155
	],
	"./zngwsyl5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zngwsyl5.entry.js",
		0,
		"common",
		156
	],
	"./zngwsyl5.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zngwsyl5.sc.entry.js",
		0,
		"common",
		157
	],
	"./zrjve6r6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zrjve6r6.entry.js",
		158
	],
	"./zrjve6r6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zrjve6r6.sc.entry.js",
		159
	],
	"./ztspkia4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ztspkia4.entry.js",
		0,
		"common",
		160
	],
	"./ztspkia4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ztspkia4.sc.entry.js",
		0,
		"common",
		161
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/@ionic/core/dist/ionic/svg sync ./!./!./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./ .svg$":
/*!**************************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/ionic/svg sync nonrecursive !./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg .svg$ ***!
  \**************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ios-add-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-add-circle-outline.svg",
	"./ios-add-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-add-circle.svg",
	"./ios-add.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-add.svg",
	"./ios-airplane.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-airplane.svg",
	"./ios-alarm.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-alarm.svg",
	"./ios-albums.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-albums.svg",
	"./ios-alert.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-alert.svg",
	"./ios-american-football.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-american-football.svg",
	"./ios-analytics.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-analytics.svg",
	"./ios-aperture.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-aperture.svg",
	"./ios-apps.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-apps.svg",
	"./ios-appstore.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-appstore.svg",
	"./ios-archive.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-archive.svg",
	"./ios-arrow-back.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-back.svg",
	"./ios-arrow-down.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-down.svg",
	"./ios-arrow-dropdown-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-dropdown-circle.svg",
	"./ios-arrow-dropdown.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-dropdown.svg",
	"./ios-arrow-dropleft-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-dropleft-circle.svg",
	"./ios-arrow-dropleft.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-dropleft.svg",
	"./ios-arrow-dropright-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-dropright-circle.svg",
	"./ios-arrow-dropright.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-dropright.svg",
	"./ios-arrow-dropup-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-dropup-circle.svg",
	"./ios-arrow-dropup.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-dropup.svg",
	"./ios-arrow-forward.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-forward.svg",
	"./ios-arrow-round-back.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-round-back.svg",
	"./ios-arrow-round-down.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-round-down.svg",
	"./ios-arrow-round-forward.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-round-forward.svg",
	"./ios-arrow-round-up.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-round-up.svg",
	"./ios-arrow-up.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-arrow-up.svg",
	"./ios-at.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-at.svg",
	"./ios-attach.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-attach.svg",
	"./ios-backspace.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-backspace.svg",
	"./ios-barcode.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-barcode.svg",
	"./ios-baseball.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-baseball.svg",
	"./ios-basket.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-basket.svg",
	"./ios-basketball.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-basketball.svg",
	"./ios-battery-charging.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-battery-charging.svg",
	"./ios-battery-dead.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-battery-dead.svg",
	"./ios-battery-full.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-battery-full.svg",
	"./ios-beaker.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-beaker.svg",
	"./ios-bed.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-bed.svg",
	"./ios-beer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-beer.svg",
	"./ios-bicycle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-bicycle.svg",
	"./ios-bluetooth.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-bluetooth.svg",
	"./ios-boat.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-boat.svg",
	"./ios-body.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-body.svg",
	"./ios-bonfire.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-bonfire.svg",
	"./ios-book.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-book.svg",
	"./ios-bookmark.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-bookmark.svg",
	"./ios-bookmarks.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-bookmarks.svg",
	"./ios-bowtie.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-bowtie.svg",
	"./ios-briefcase.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-briefcase.svg",
	"./ios-browsers.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-browsers.svg",
	"./ios-brush.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-brush.svg",
	"./ios-bug.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-bug.svg",
	"./ios-build.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-build.svg",
	"./ios-bulb.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-bulb.svg",
	"./ios-bus.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-bus.svg",
	"./ios-business.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-business.svg",
	"./ios-cafe.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cafe.svg",
	"./ios-calculator.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-calculator.svg",
	"./ios-calendar.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-calendar.svg",
	"./ios-call.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-call.svg",
	"./ios-camera.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-camera.svg",
	"./ios-car.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-car.svg",
	"./ios-card.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-card.svg",
	"./ios-cart.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cart.svg",
	"./ios-cash.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cash.svg",
	"./ios-cellular.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cellular.svg",
	"./ios-chatboxes.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-chatboxes.svg",
	"./ios-chatbubbles.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-chatbubbles.svg",
	"./ios-checkbox-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-checkbox-outline.svg",
	"./ios-checkbox.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-checkbox.svg",
	"./ios-checkmark-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-checkmark-circle-outline.svg",
	"./ios-checkmark-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-checkmark-circle.svg",
	"./ios-checkmark.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-checkmark.svg",
	"./ios-clipboard.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-clipboard.svg",
	"./ios-clock.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-clock.svg",
	"./ios-close-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-close-circle-outline.svg",
	"./ios-close-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-close-circle.svg",
	"./ios-close.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-close.svg",
	"./ios-cloud-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cloud-circle.svg",
	"./ios-cloud-done.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cloud-done.svg",
	"./ios-cloud-download.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cloud-download.svg",
	"./ios-cloud-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cloud-outline.svg",
	"./ios-cloud-upload.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cloud-upload.svg",
	"./ios-cloud.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cloud.svg",
	"./ios-cloudy-night.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cloudy-night.svg",
	"./ios-cloudy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cloudy.svg",
	"./ios-code-download.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-code-download.svg",
	"./ios-code-working.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-code-working.svg",
	"./ios-code.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-code.svg",
	"./ios-cog.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cog.svg",
	"./ios-color-fill.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-color-fill.svg",
	"./ios-color-filter.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-color-filter.svg",
	"./ios-color-palette.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-color-palette.svg",
	"./ios-color-wand.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-color-wand.svg",
	"./ios-compass.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-compass.svg",
	"./ios-construct.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-construct.svg",
	"./ios-contact.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-contact.svg",
	"./ios-contacts.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-contacts.svg",
	"./ios-contract.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-contract.svg",
	"./ios-contrast.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-contrast.svg",
	"./ios-copy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-copy.svg",
	"./ios-create.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-create.svg",
	"./ios-crop.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-crop.svg",
	"./ios-cube.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cube.svg",
	"./ios-cut.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-cut.svg",
	"./ios-desktop.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-desktop.svg",
	"./ios-disc.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-disc.svg",
	"./ios-document.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-document.svg",
	"./ios-done-all.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-done-all.svg",
	"./ios-download.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-download.svg",
	"./ios-easel.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-easel.svg",
	"./ios-egg.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-egg.svg",
	"./ios-exit.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-exit.svg",
	"./ios-expand.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-expand.svg",
	"./ios-eye-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-eye-off.svg",
	"./ios-eye.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-eye.svg",
	"./ios-fastforward.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-fastforward.svg",
	"./ios-female.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-female.svg",
	"./ios-filing.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-filing.svg",
	"./ios-film.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-film.svg",
	"./ios-finger-print.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-finger-print.svg",
	"./ios-fitness.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-fitness.svg",
	"./ios-flag.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-flag.svg",
	"./ios-flame.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-flame.svg",
	"./ios-flash-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-flash-off.svg",
	"./ios-flash.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-flash.svg",
	"./ios-flashlight.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-flashlight.svg",
	"./ios-flask.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-flask.svg",
	"./ios-flower.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-flower.svg",
	"./ios-folder-open.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-folder-open.svg",
	"./ios-folder.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-folder.svg",
	"./ios-football.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-football.svg",
	"./ios-funnel.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-funnel.svg",
	"./ios-gift.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-gift.svg",
	"./ios-git-branch.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-git-branch.svg",
	"./ios-git-commit.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-git-commit.svg",
	"./ios-git-compare.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-git-compare.svg",
	"./ios-git-merge.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-git-merge.svg",
	"./ios-git-network.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-git-network.svg",
	"./ios-git-pull-request.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-git-pull-request.svg",
	"./ios-glasses.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-glasses.svg",
	"./ios-globe.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-globe.svg",
	"./ios-grid.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-grid.svg",
	"./ios-hammer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-hammer.svg",
	"./ios-hand.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-hand.svg",
	"./ios-happy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-happy.svg",
	"./ios-headset.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-headset.svg",
	"./ios-heart-dislike.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-heart-dislike.svg",
	"./ios-heart-empty.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-heart-empty.svg",
	"./ios-heart-half.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-heart-half.svg",
	"./ios-heart.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-heart.svg",
	"./ios-help-buoy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-help-buoy.svg",
	"./ios-help-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-help-circle-outline.svg",
	"./ios-help-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-help-circle.svg",
	"./ios-help.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-help.svg",
	"./ios-home.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-home.svg",
	"./ios-hourglass.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-hourglass.svg",
	"./ios-ice-cream.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-ice-cream.svg",
	"./ios-image.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-image.svg",
	"./ios-images.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-images.svg",
	"./ios-infinite.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-infinite.svg",
	"./ios-information-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-information-circle-outline.svg",
	"./ios-information-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-information-circle.svg",
	"./ios-information.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-information.svg",
	"./ios-jet.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-jet.svg",
	"./ios-journal.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-journal.svg",
	"./ios-key.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-key.svg",
	"./ios-keypad.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-keypad.svg",
	"./ios-laptop.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-laptop.svg",
	"./ios-leaf.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-leaf.svg",
	"./ios-link.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-link.svg",
	"./ios-list-box.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-list-box.svg",
	"./ios-list.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-list.svg",
	"./ios-locate.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-locate.svg",
	"./ios-lock.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-lock.svg",
	"./ios-log-in.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-log-in.svg",
	"./ios-log-out.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-log-out.svg",
	"./ios-magnet.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-magnet.svg",
	"./ios-mail-open.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-mail-open.svg",
	"./ios-mail-unread.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-mail-unread.svg",
	"./ios-mail.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-mail.svg",
	"./ios-male.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-male.svg",
	"./ios-man.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-man.svg",
	"./ios-map.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-map.svg",
	"./ios-medal.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-medal.svg",
	"./ios-medical.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-medical.svg",
	"./ios-medkit.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-medkit.svg",
	"./ios-megaphone.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-megaphone.svg",
	"./ios-menu.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-menu.svg",
	"./ios-mic-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-mic-off.svg",
	"./ios-mic.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-mic.svg",
	"./ios-microphone.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-microphone.svg",
	"./ios-moon.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-moon.svg",
	"./ios-more.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-more.svg",
	"./ios-move.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-move.svg",
	"./ios-musical-note.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-musical-note.svg",
	"./ios-musical-notes.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-musical-notes.svg",
	"./ios-navigate.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-navigate.svg",
	"./ios-notifications-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-notifications-off.svg",
	"./ios-notifications-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-notifications-outline.svg",
	"./ios-notifications.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-notifications.svg",
	"./ios-nuclear.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-nuclear.svg",
	"./ios-nutrition.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-nutrition.svg",
	"./ios-open.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-open.svg",
	"./ios-options.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-options.svg",
	"./ios-outlet.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-outlet.svg",
	"./ios-paper-plane.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-paper-plane.svg",
	"./ios-paper.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-paper.svg",
	"./ios-partly-sunny.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-partly-sunny.svg",
	"./ios-pause.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-pause.svg",
	"./ios-paw.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-paw.svg",
	"./ios-people.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-people.svg",
	"./ios-person-add.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-person-add.svg",
	"./ios-person.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-person.svg",
	"./ios-phone-landscape.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-phone-landscape.svg",
	"./ios-phone-portrait.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-phone-portrait.svg",
	"./ios-photos.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-photos.svg",
	"./ios-pie.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-pie.svg",
	"./ios-pin.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-pin.svg",
	"./ios-pint.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-pint.svg",
	"./ios-pizza.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-pizza.svg",
	"./ios-planet.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-planet.svg",
	"./ios-play-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-play-circle.svg",
	"./ios-play.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-play.svg",
	"./ios-podium.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-podium.svg",
	"./ios-power.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-power.svg",
	"./ios-pricetag.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-pricetag.svg",
	"./ios-pricetags.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-pricetags.svg",
	"./ios-print.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-print.svg",
	"./ios-pulse.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-pulse.svg",
	"./ios-qr-scanner.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-qr-scanner.svg",
	"./ios-quote.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-quote.svg",
	"./ios-radio-button-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-radio-button-off.svg",
	"./ios-radio-button-on.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-radio-button-on.svg",
	"./ios-radio.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-radio.svg",
	"./ios-rainy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-rainy.svg",
	"./ios-recording.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-recording.svg",
	"./ios-redo.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-redo.svg",
	"./ios-refresh-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-refresh-circle.svg",
	"./ios-refresh.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-refresh.svg",
	"./ios-remove-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-remove-circle-outline.svg",
	"./ios-remove-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-remove-circle.svg",
	"./ios-remove.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-remove.svg",
	"./ios-reorder.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-reorder.svg",
	"./ios-repeat.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-repeat.svg",
	"./ios-resize.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-resize.svg",
	"./ios-restaurant.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-restaurant.svg",
	"./ios-return-left.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-return-left.svg",
	"./ios-return-right.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-return-right.svg",
	"./ios-reverse-camera.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-reverse-camera.svg",
	"./ios-rewind.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-rewind.svg",
	"./ios-ribbon.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-ribbon.svg",
	"./ios-rocket.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-rocket.svg",
	"./ios-rose.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-rose.svg",
	"./ios-sad.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-sad.svg",
	"./ios-save.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-save.svg",
	"./ios-school.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-school.svg",
	"./ios-search.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-search.svg",
	"./ios-send.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-send.svg",
	"./ios-settings.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-settings.svg",
	"./ios-share-alt.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-share-alt.svg",
	"./ios-share.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-share.svg",
	"./ios-shirt.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-shirt.svg",
	"./ios-shuffle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-shuffle.svg",
	"./ios-skip-backward.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-skip-backward.svg",
	"./ios-skip-forward.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-skip-forward.svg",
	"./ios-snow.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-snow.svg",
	"./ios-speedometer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-speedometer.svg",
	"./ios-square-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-square-outline.svg",
	"./ios-square.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-square.svg",
	"./ios-star-half.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-star-half.svg",
	"./ios-star-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-star-outline.svg",
	"./ios-star.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-star.svg",
	"./ios-stats.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-stats.svg",
	"./ios-stopwatch.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-stopwatch.svg",
	"./ios-subway.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-subway.svg",
	"./ios-sunny.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-sunny.svg",
	"./ios-swap.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-swap.svg",
	"./ios-switch.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-switch.svg",
	"./ios-sync.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-sync.svg",
	"./ios-tablet-landscape.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-tablet-landscape.svg",
	"./ios-tablet-portrait.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-tablet-portrait.svg",
	"./ios-tennisball.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-tennisball.svg",
	"./ios-text.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-text.svg",
	"./ios-thermometer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-thermometer.svg",
	"./ios-thumbs-down.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-thumbs-down.svg",
	"./ios-thumbs-up.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-thumbs-up.svg",
	"./ios-thunderstorm.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-thunderstorm.svg",
	"./ios-time.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-time.svg",
	"./ios-timer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-timer.svg",
	"./ios-today.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-today.svg",
	"./ios-train.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-train.svg",
	"./ios-transgender.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-transgender.svg",
	"./ios-trash.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-trash.svg",
	"./ios-trending-down.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-trending-down.svg",
	"./ios-trending-up.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-trending-up.svg",
	"./ios-trophy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-trophy.svg",
	"./ios-tv.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-tv.svg",
	"./ios-umbrella.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-umbrella.svg",
	"./ios-undo.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-undo.svg",
	"./ios-unlock.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-unlock.svg",
	"./ios-videocam.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-videocam.svg",
	"./ios-volume-high.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-volume-high.svg",
	"./ios-volume-low.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-volume-low.svg",
	"./ios-volume-mute.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-volume-mute.svg",
	"./ios-volume-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-volume-off.svg",
	"./ios-walk.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-walk.svg",
	"./ios-wallet.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-wallet.svg",
	"./ios-warning.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-warning.svg",
	"./ios-watch.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-watch.svg",
	"./ios-water.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-water.svg",
	"./ios-wifi.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-wifi.svg",
	"./ios-wine.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-wine.svg",
	"./ios-woman.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/ios-woman.svg",
	"./logo-android.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-android.svg",
	"./logo-angular.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-angular.svg",
	"./logo-apple.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-apple.svg",
	"./logo-bitbucket.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-bitbucket.svg",
	"./logo-bitcoin.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-bitcoin.svg",
	"./logo-buffer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-buffer.svg",
	"./logo-chrome.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-chrome.svg",
	"./logo-closed-captioning.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-closed-captioning.svg",
	"./logo-codepen.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-codepen.svg",
	"./logo-css3.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-css3.svg",
	"./logo-designernews.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-designernews.svg",
	"./logo-dribbble.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-dribbble.svg",
	"./logo-dropbox.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-dropbox.svg",
	"./logo-euro.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-euro.svg",
	"./logo-facebook.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-facebook.svg",
	"./logo-flickr.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-flickr.svg",
	"./logo-foursquare.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-foursquare.svg",
	"./logo-freebsd-devil.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-freebsd-devil.svg",
	"./logo-game-controller-a.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-game-controller-a.svg",
	"./logo-game-controller-b.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-game-controller-b.svg",
	"./logo-github.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-github.svg",
	"./logo-google.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-google.svg",
	"./logo-googleplus.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-googleplus.svg",
	"./logo-hackernews.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-hackernews.svg",
	"./logo-html5.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-html5.svg",
	"./logo-instagram.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-instagram.svg",
	"./logo-ionic.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-ionic.svg",
	"./logo-ionitron.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-ionitron.svg",
	"./logo-javascript.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-javascript.svg",
	"./logo-linkedin.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-linkedin.svg",
	"./logo-markdown.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-markdown.svg",
	"./logo-model-s.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-model-s.svg",
	"./logo-no-smoking.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-no-smoking.svg",
	"./logo-nodejs.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-nodejs.svg",
	"./logo-npm.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-npm.svg",
	"./logo-octocat.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-octocat.svg",
	"./logo-pinterest.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-pinterest.svg",
	"./logo-playstation.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-playstation.svg",
	"./logo-polymer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-polymer.svg",
	"./logo-python.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-python.svg",
	"./logo-reddit.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-reddit.svg",
	"./logo-rss.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-rss.svg",
	"./logo-sass.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-sass.svg",
	"./logo-skype.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-skype.svg",
	"./logo-slack.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-slack.svg",
	"./logo-snapchat.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-snapchat.svg",
	"./logo-steam.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-steam.svg",
	"./logo-tumblr.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-tumblr.svg",
	"./logo-tux.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-tux.svg",
	"./logo-twitch.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-twitch.svg",
	"./logo-twitter.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-twitter.svg",
	"./logo-usd.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-usd.svg",
	"./logo-vimeo.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-vimeo.svg",
	"./logo-vk.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-vk.svg",
	"./logo-whatsapp.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-whatsapp.svg",
	"./logo-windows.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-windows.svg",
	"./logo-wordpress.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-wordpress.svg",
	"./logo-xbox.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-xbox.svg",
	"./logo-xing.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-xing.svg",
	"./logo-yahoo.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-yahoo.svg",
	"./logo-yen.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-yen.svg",
	"./logo-youtube.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/logo-youtube.svg",
	"./md-add-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-add-circle-outline.svg",
	"./md-add-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-add-circle.svg",
	"./md-add.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-add.svg",
	"./md-airplane.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-airplane.svg",
	"./md-alarm.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-alarm.svg",
	"./md-albums.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-albums.svg",
	"./md-alert.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-alert.svg",
	"./md-american-football.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-american-football.svg",
	"./md-analytics.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-analytics.svg",
	"./md-aperture.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-aperture.svg",
	"./md-apps.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-apps.svg",
	"./md-appstore.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-appstore.svg",
	"./md-archive.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-archive.svg",
	"./md-arrow-back.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-back.svg",
	"./md-arrow-down.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-down.svg",
	"./md-arrow-dropdown-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-dropdown-circle.svg",
	"./md-arrow-dropdown.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-dropdown.svg",
	"./md-arrow-dropleft-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-dropleft-circle.svg",
	"./md-arrow-dropleft.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-dropleft.svg",
	"./md-arrow-dropright-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-dropright-circle.svg",
	"./md-arrow-dropright.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-dropright.svg",
	"./md-arrow-dropup-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-dropup-circle.svg",
	"./md-arrow-dropup.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-dropup.svg",
	"./md-arrow-forward.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-forward.svg",
	"./md-arrow-round-back.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-round-back.svg",
	"./md-arrow-round-down.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-round-down.svg",
	"./md-arrow-round-forward.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-round-forward.svg",
	"./md-arrow-round-up.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-round-up.svg",
	"./md-arrow-up.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-arrow-up.svg",
	"./md-at.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-at.svg",
	"./md-attach.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-attach.svg",
	"./md-backspace.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-backspace.svg",
	"./md-barcode.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-barcode.svg",
	"./md-baseball.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-baseball.svg",
	"./md-basket.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-basket.svg",
	"./md-basketball.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-basketball.svg",
	"./md-battery-charging.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-battery-charging.svg",
	"./md-battery-dead.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-battery-dead.svg",
	"./md-battery-full.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-battery-full.svg",
	"./md-beaker.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-beaker.svg",
	"./md-bed.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-bed.svg",
	"./md-beer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-beer.svg",
	"./md-bicycle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-bicycle.svg",
	"./md-bluetooth.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-bluetooth.svg",
	"./md-boat.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-boat.svg",
	"./md-body.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-body.svg",
	"./md-bonfire.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-bonfire.svg",
	"./md-book.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-book.svg",
	"./md-bookmark.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-bookmark.svg",
	"./md-bookmarks.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-bookmarks.svg",
	"./md-bowtie.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-bowtie.svg",
	"./md-briefcase.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-briefcase.svg",
	"./md-browsers.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-browsers.svg",
	"./md-brush.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-brush.svg",
	"./md-bug.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-bug.svg",
	"./md-build.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-build.svg",
	"./md-bulb.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-bulb.svg",
	"./md-bus.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-bus.svg",
	"./md-business.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-business.svg",
	"./md-cafe.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cafe.svg",
	"./md-calculator.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-calculator.svg",
	"./md-calendar.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-calendar.svg",
	"./md-call.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-call.svg",
	"./md-camera.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-camera.svg",
	"./md-car.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-car.svg",
	"./md-card.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-card.svg",
	"./md-cart.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cart.svg",
	"./md-cash.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cash.svg",
	"./md-cellular.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cellular.svg",
	"./md-chatboxes.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-chatboxes.svg",
	"./md-chatbubbles.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-chatbubbles.svg",
	"./md-checkbox-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-checkbox-outline.svg",
	"./md-checkbox.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-checkbox.svg",
	"./md-checkmark-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-checkmark-circle-outline.svg",
	"./md-checkmark-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-checkmark-circle.svg",
	"./md-checkmark.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-checkmark.svg",
	"./md-clipboard.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-clipboard.svg",
	"./md-clock.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-clock.svg",
	"./md-close-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-close-circle-outline.svg",
	"./md-close-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-close-circle.svg",
	"./md-close.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-close.svg",
	"./md-cloud-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cloud-circle.svg",
	"./md-cloud-done.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cloud-done.svg",
	"./md-cloud-download.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cloud-download.svg",
	"./md-cloud-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cloud-outline.svg",
	"./md-cloud-upload.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cloud-upload.svg",
	"./md-cloud.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cloud.svg",
	"./md-cloudy-night.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cloudy-night.svg",
	"./md-cloudy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cloudy.svg",
	"./md-code-download.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-code-download.svg",
	"./md-code-working.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-code-working.svg",
	"./md-code.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-code.svg",
	"./md-cog.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cog.svg",
	"./md-color-fill.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-color-fill.svg",
	"./md-color-filter.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-color-filter.svg",
	"./md-color-palette.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-color-palette.svg",
	"./md-color-wand.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-color-wand.svg",
	"./md-compass.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-compass.svg",
	"./md-construct.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-construct.svg",
	"./md-contact.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-contact.svg",
	"./md-contacts.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-contacts.svg",
	"./md-contract.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-contract.svg",
	"./md-contrast.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-contrast.svg",
	"./md-copy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-copy.svg",
	"./md-create.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-create.svg",
	"./md-crop.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-crop.svg",
	"./md-cube.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cube.svg",
	"./md-cut.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-cut.svg",
	"./md-desktop.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-desktop.svg",
	"./md-disc.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-disc.svg",
	"./md-document.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-document.svg",
	"./md-done-all.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-done-all.svg",
	"./md-download.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-download.svg",
	"./md-easel.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-easel.svg",
	"./md-egg.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-egg.svg",
	"./md-exit.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-exit.svg",
	"./md-expand.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-expand.svg",
	"./md-eye-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-eye-off.svg",
	"./md-eye.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-eye.svg",
	"./md-fastforward.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-fastforward.svg",
	"./md-female.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-female.svg",
	"./md-filing.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-filing.svg",
	"./md-film.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-film.svg",
	"./md-finger-print.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-finger-print.svg",
	"./md-fitness.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-fitness.svg",
	"./md-flag.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-flag.svg",
	"./md-flame.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-flame.svg",
	"./md-flash-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-flash-off.svg",
	"./md-flash.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-flash.svg",
	"./md-flashlight.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-flashlight.svg",
	"./md-flask.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-flask.svg",
	"./md-flower.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-flower.svg",
	"./md-folder-open.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-folder-open.svg",
	"./md-folder.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-folder.svg",
	"./md-football.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-football.svg",
	"./md-funnel.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-funnel.svg",
	"./md-gift.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-gift.svg",
	"./md-git-branch.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-git-branch.svg",
	"./md-git-commit.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-git-commit.svg",
	"./md-git-compare.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-git-compare.svg",
	"./md-git-merge.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-git-merge.svg",
	"./md-git-network.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-git-network.svg",
	"./md-git-pull-request.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-git-pull-request.svg",
	"./md-glasses.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-glasses.svg",
	"./md-globe.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-globe.svg",
	"./md-grid.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-grid.svg",
	"./md-hammer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-hammer.svg",
	"./md-hand.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-hand.svg",
	"./md-happy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-happy.svg",
	"./md-headset.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-headset.svg",
	"./md-heart-dislike.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-heart-dislike.svg",
	"./md-heart-empty.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-heart-empty.svg",
	"./md-heart-half.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-heart-half.svg",
	"./md-heart.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-heart.svg",
	"./md-help-buoy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-help-buoy.svg",
	"./md-help-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-help-circle-outline.svg",
	"./md-help-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-help-circle.svg",
	"./md-help.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-help.svg",
	"./md-home.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-home.svg",
	"./md-hourglass.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-hourglass.svg",
	"./md-ice-cream.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-ice-cream.svg",
	"./md-image.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-image.svg",
	"./md-images.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-images.svg",
	"./md-infinite.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-infinite.svg",
	"./md-information-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-information-circle-outline.svg",
	"./md-information-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-information-circle.svg",
	"./md-information.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-information.svg",
	"./md-jet.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-jet.svg",
	"./md-journal.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-journal.svg",
	"./md-key.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-key.svg",
	"./md-keypad.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-keypad.svg",
	"./md-laptop.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-laptop.svg",
	"./md-leaf.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-leaf.svg",
	"./md-link.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-link.svg",
	"./md-list-box.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-list-box.svg",
	"./md-list.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-list.svg",
	"./md-locate.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-locate.svg",
	"./md-lock.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-lock.svg",
	"./md-log-in.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-log-in.svg",
	"./md-log-out.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-log-out.svg",
	"./md-magnet.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-magnet.svg",
	"./md-mail-open.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-mail-open.svg",
	"./md-mail-unread.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-mail-unread.svg",
	"./md-mail.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-mail.svg",
	"./md-male.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-male.svg",
	"./md-man.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-man.svg",
	"./md-map.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-map.svg",
	"./md-medal.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-medal.svg",
	"./md-medical.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-medical.svg",
	"./md-medkit.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-medkit.svg",
	"./md-megaphone.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-megaphone.svg",
	"./md-menu.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-menu.svg",
	"./md-mic-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-mic-off.svg",
	"./md-mic.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-mic.svg",
	"./md-microphone.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-microphone.svg",
	"./md-moon.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-moon.svg",
	"./md-more.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-more.svg",
	"./md-move.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-move.svg",
	"./md-musical-note.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-musical-note.svg",
	"./md-musical-notes.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-musical-notes.svg",
	"./md-navigate.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-navigate.svg",
	"./md-notifications-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-notifications-off.svg",
	"./md-notifications-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-notifications-outline.svg",
	"./md-notifications.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-notifications.svg",
	"./md-nuclear.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-nuclear.svg",
	"./md-nutrition.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-nutrition.svg",
	"./md-open.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-open.svg",
	"./md-options.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-options.svg",
	"./md-outlet.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-outlet.svg",
	"./md-paper-plane.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-paper-plane.svg",
	"./md-paper.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-paper.svg",
	"./md-partly-sunny.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-partly-sunny.svg",
	"./md-pause.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-pause.svg",
	"./md-paw.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-paw.svg",
	"./md-people.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-people.svg",
	"./md-person-add.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-person-add.svg",
	"./md-person.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-person.svg",
	"./md-phone-landscape.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-phone-landscape.svg",
	"./md-phone-portrait.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-phone-portrait.svg",
	"./md-photos.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-photos.svg",
	"./md-pie.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-pie.svg",
	"./md-pin.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-pin.svg",
	"./md-pint.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-pint.svg",
	"./md-pizza.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-pizza.svg",
	"./md-planet.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-planet.svg",
	"./md-play-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-play-circle.svg",
	"./md-play.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-play.svg",
	"./md-podium.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-podium.svg",
	"./md-power.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-power.svg",
	"./md-pricetag.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-pricetag.svg",
	"./md-pricetags.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-pricetags.svg",
	"./md-print.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-print.svg",
	"./md-pulse.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-pulse.svg",
	"./md-qr-scanner.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-qr-scanner.svg",
	"./md-quote.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-quote.svg",
	"./md-radio-button-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-radio-button-off.svg",
	"./md-radio-button-on.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-radio-button-on.svg",
	"./md-radio.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-radio.svg",
	"./md-rainy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-rainy.svg",
	"./md-recording.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-recording.svg",
	"./md-redo.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-redo.svg",
	"./md-refresh-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-refresh-circle.svg",
	"./md-refresh.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-refresh.svg",
	"./md-remove-circle-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-remove-circle-outline.svg",
	"./md-remove-circle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-remove-circle.svg",
	"./md-remove.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-remove.svg",
	"./md-reorder.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-reorder.svg",
	"./md-repeat.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-repeat.svg",
	"./md-resize.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-resize.svg",
	"./md-restaurant.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-restaurant.svg",
	"./md-return-left.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-return-left.svg",
	"./md-return-right.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-return-right.svg",
	"./md-reverse-camera.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-reverse-camera.svg",
	"./md-rewind.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-rewind.svg",
	"./md-ribbon.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-ribbon.svg",
	"./md-rocket.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-rocket.svg",
	"./md-rose.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-rose.svg",
	"./md-sad.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-sad.svg",
	"./md-save.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-save.svg",
	"./md-school.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-school.svg",
	"./md-search.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-search.svg",
	"./md-send.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-send.svg",
	"./md-settings.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-settings.svg",
	"./md-share-alt.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-share-alt.svg",
	"./md-share.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-share.svg",
	"./md-shirt.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-shirt.svg",
	"./md-shuffle.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-shuffle.svg",
	"./md-skip-backward.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-skip-backward.svg",
	"./md-skip-forward.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-skip-forward.svg",
	"./md-snow.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-snow.svg",
	"./md-speedometer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-speedometer.svg",
	"./md-square-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-square-outline.svg",
	"./md-square.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-square.svg",
	"./md-star-half.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-star-half.svg",
	"./md-star-outline.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-star-outline.svg",
	"./md-star.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-star.svg",
	"./md-stats.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-stats.svg",
	"./md-stopwatch.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-stopwatch.svg",
	"./md-subway.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-subway.svg",
	"./md-sunny.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-sunny.svg",
	"./md-swap.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-swap.svg",
	"./md-switch.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-switch.svg",
	"./md-sync.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-sync.svg",
	"./md-tablet-landscape.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-tablet-landscape.svg",
	"./md-tablet-portrait.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-tablet-portrait.svg",
	"./md-tennisball.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-tennisball.svg",
	"./md-text.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-text.svg",
	"./md-thermometer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-thermometer.svg",
	"./md-thumbs-down.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-thumbs-down.svg",
	"./md-thumbs-up.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-thumbs-up.svg",
	"./md-thunderstorm.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-thunderstorm.svg",
	"./md-time.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-time.svg",
	"./md-timer.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-timer.svg",
	"./md-today.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-today.svg",
	"./md-train.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-train.svg",
	"./md-transgender.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-transgender.svg",
	"./md-trash.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-trash.svg",
	"./md-trending-down.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-trending-down.svg",
	"./md-trending-up.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-trending-up.svg",
	"./md-trophy.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-trophy.svg",
	"./md-tv.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-tv.svg",
	"./md-umbrella.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-umbrella.svg",
	"./md-undo.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-undo.svg",
	"./md-unlock.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-unlock.svg",
	"./md-videocam.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-videocam.svg",
	"./md-volume-high.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-volume-high.svg",
	"./md-volume-low.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-volume-low.svg",
	"./md-volume-mute.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-volume-mute.svg",
	"./md-volume-off.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-volume-off.svg",
	"./md-walk.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-walk.svg",
	"./md-wallet.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-wallet.svg",
	"./md-warning.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-warning.svg",
	"./md-watch.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-watch.svg",
	"./md-water.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-water.svg",
	"./md-wifi.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-wifi.svg",
	"./md-wine.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-wine.svg",
	"./md-woman.svg": "./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./node_modules/@ionic/core/dist/ionic/svg/md-woman.svg"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/@ionic/core/dist/ionic/svg sync ./!./!./node_modules/file-loader/dist/cjs.js?name=[name].[ext]&outputPath=svg!./ .svg$";

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./answer/answer.module": [
		"./src/app/answer/answer.module.ts",
		"common",
		"answer-answer-module"
	],
	"./auth/loginpage/loginpage.module": [
		"./src/app/auth/loginpage/loginpage.module.ts",
		"common",
		"auth-loginpage-loginpage-module"
	],
	"./auth/signup1/signup1.module": [
		"./src/app/auth/signup1/signup1.module.ts",
		"common",
		"auth-signup1-signup1-module"
	],
	"./auth/signup2/signup2.module": [
		"./src/app/auth/signup2/signup2.module.ts",
		"common",
		"auth-signup2-signup2-module"
	],
	"./auth/signuppage/signuppage.module": [
		"./src/app/auth/signuppage/signuppage.module.ts",
		"common",
		"auth-signuppage-signuppage-module"
	],
	"./comparison/usercomparison/usercomparison.module": [
		"./src/app/comparison/usercomparison/usercomparison.module.ts",
		"default~comparison-usercomparison-usercomparison-module~tab-tab-module",
		"common"
	],
	"./index/login.module": [
		"./src/app/index/login.module.ts",
		"index-login-module"
	],
	"./tab/tab.module": [
		"./src/app/tab/tab.module.ts",
		"default~comparison-usercomparison-usercomparison-module~tab-tab-module",
		"common",
		"tab-tab-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var routes = [
    { path: '', redirectTo: 'index', pathMatch: 'full' },
    { path: 'index', loadChildren: './index/login.module#LoginPageModule' },
    { path: 'loginpage', loadChildren: './auth/loginpage/loginpage.module#LoginpagePageModule' },
    { path: 'signuppage', loadChildren: './auth/signuppage/signuppage.module#SignuppagePageModule' },
    { path: 'signup1', loadChildren: './auth/signup1/signup1.module#Signup1PageModule' },
    { path: 'signup2', loadChildren: './auth/signup2/signup2.module#Signup2PageModule' },
    // { path: 'question', loadChildren: './question/question.module#QuestionPageModule' },
    // { path: 'profile', loadChildren: './profile/profile.module#ProfilePageModule' },
    // { path: 'permissions', loadChildren: './permissions/permissions.module#PermissionsPageModule' },
    { path: 'answer', loadChildren: './answer/answer.module#AnswerPageModule' },
    { path: '', loadChildren: './tab/tab.module#TabPageModule' },
    { path: 'usercomparison', loadChildren: './comparison/usercomparison/usercomparison.module#UsercomparisonPageModule' },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <div class={{themeClass}}>\n  <ion-router-outlet></ion-router-outlet>\n  </div>\n</ion-app>\n\n<script src=\"https://www.gstatic.com/firebasejs/5.5.9/firebase.js\"></script>\n<!-- <script>\n  // Initialize Firebase\n  var config = {\n    apiKey: \"AIzaSyDoLmR4cYxuEt2026yNazIX0G8Amjv_cFg\",\n    authDomain: \"deep-personality.firebaseapp.com\",\n    databaseURL: \"https://deep-personality.firebaseio.com\",\n    projectId: \"deep-personality\",\n    storageBucket: \"deep-personality.appspot.com\",\n    messagingSenderId: \"893488855789\"\n  };\n  firebase.initializeApp(config);\n</script> -->"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, events) {
        var _this = this;
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.events = events;
        this.initializeApp();
        events.subscribe('user:theme_color', function (theme_color) {
            console.log('theme_color is', theme_color);
            if (theme_color === 'dark') {
                _this.themeClass = 'theme-clover';
            }
            else {
                _this.themeClass = 'theme-noir';
            }
        });
        this.themes = [
            // { title: 'Default Red', theme: 'theme-red', color:'assets/imgs/FF0000.png' },
            { title: 'Noir', theme: 'theme-noir', color: 'assets/imgs/333333.png' },
            { title: 'Clover', theme: 'theme-clover', color: 'assets/imgs/388E3C.png' },
        ];
        this.themeClass = 'theme-clover';
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
            Notification.requestPermission().then(function (result) {
                console.log(result);
                setInterval(function () {
                    var notification = new Notification("Hi there!");
                }, 5000);
            });
        });
    };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__["StatusBar"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Events"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/fire */ "./node_modules/@angular/fire/index.js");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/fire/auth */ "./node_modules/@angular/fire/auth/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};













var firebaseConfig = {
    apiKey: "AIzaSyC-xNprG3bSnEcD0SOF0z59t8QzYy3U0u0",
    authDomain: "deep-personality.firebaseapp.com",
    databaseURL: "https://deep-personality.firebaseio.com",
    projectId: "deep-personality",
    storageBucket: "deep-personality.appspot.com",
    messagingSenderId: "893488855789"
};
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]],
            entryComponents: [],
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"].forRoot(),
                _ionic_storage__WEBPACK_IMPORTED_MODULE_10__["IonicStorageModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_9__["AppRoutingModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_3__["HttpModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientJsonpModule"],
                _angular_fire_auth__WEBPACK_IMPORTED_MODULE_12__["AngularFireAuthModule"],
                _angular_fire__WEBPACK_IMPORTED_MODULE_11__["AngularFireModule"].initializeApp(firebaseConfig),
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
var environment = {
    production: false
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/admin/Documents/Ionic_Projects/Ionic4-Angular6_DeepPersonality_App/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map