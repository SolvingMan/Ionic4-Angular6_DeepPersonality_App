(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab-tab-module"],{

/***/ "./src/app/comparison/comparison.module.ts":
/*!*************************************************!*\
  !*** ./src/app/comparison/comparison.module.ts ***!
  \*************************************************/
/*! exports provided: ComparisonPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComparisonPageModule", function() { return ComparisonPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _comparison_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./comparison.page */ "./src/app/comparison/comparison.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _comparison_page__WEBPACK_IMPORTED_MODULE_5__["ComparisonPage"]
    }
];
var ComparisonPageModule = /** @class */ (function () {
    function ComparisonPageModule() {
    }
    ComparisonPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_comparison_page__WEBPACK_IMPORTED_MODULE_5__["ComparisonPage"]]
        })
    ], ComparisonPageModule);
    return ComparisonPageModule;
}());



/***/ }),

/***/ "./src/app/comparison/comparison.page.html":
/*!*************************************************!*\
  !*** ./src/app/comparison/comparison.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content padding>\n  <div padding text-center item-text style=\"display: flex;  justify-content: center;  align-items: center; padding-top: 45px\">\n      <ion-label class=\"title\">Comparison</ion-label>\n      <ion-icon class=\"title_icon\" name=\"md-text\"></ion-icon>\n  </div>\n\n  <div padding-top>\n    <ion-segment [(ngModel)]=\"viewMode\">\n      <ion-segment-button value=\"date\">\n        <ion-label>DATE SHARED</ion-label>\n\n      </ion-segment-button>\n      <ion-segment-button value=\"alphabet\">\n        <ion-label>ALPHABET</ion-label>\n      </ion-segment-button>\n    </ion-segment>\n  </div>\n\n<div *ngIf=\"viewMode == 'date'\" padding-top style=\"border-radius: 10px\">\n  <ion-list>\n    <ion-item \n      *ngFor='let user of this.all_compares; let i = index'\n      [href]=\"'/tab/(comparison:usercomparison/'+i\"\n      detail=\"true\">\n      <ion-label>{{user.email}}</ion-label>      \n    </ion-item>\n  </ion-list>\n</div>\n\n  <div *ngIf=\"viewMode === 'alphabet'\" padding-top style=\"border-radius: 10px\">\n    <ion-list>\n      <ion-item \n        *ngFor='let user of this.all_compares_sort; let i = index'\n        [href]=\"'/tab/(comparison:usercomparison/'+i\"\n        detail=\"true\">\n        <ion-label>{{user.email}}</ion-label>      \n      </ion-item>\n    </ion-list>\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/comparison/comparison.page.scss":
/*!*************************************************!*\
  !*** ./src/app/comparison/comparison.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-segment-button {\n  font-size: unset;\n  height: 37px;\n  --border-radius: 10px; }\n\nion-segment {\n  --background-checked: #fafafa;\n  --color: #fafafa;\n  --color-checked: #2B2A2F;\n  --border-color-checked: #fafafa; }\n\nion-item {\n  --inner-border-width: 0;\n  --border-width: 0 0 1px 0;\n  --ion-color-shade: #f2f2f2 !important;\n  --detail-icon-opacity: 1; }\n"

/***/ }),

/***/ "./src/app/comparison/comparison.page.ts":
/*!***********************************************!*\
  !*** ./src/app/comparison/comparison.page.ts ***!
  \***********************************************/
/*! exports provided: ComparisonPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComparisonPage", function() { return ComparisonPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/user-data.service */ "./src/app/provider/user-data.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var ComparisonPage = /** @class */ (function () {
    function ComparisonPage(router, http, navCtrl, userData, events, alertCtrl) {
        var _this = this;
        this.router = router;
        this.http = http;
        this.navCtrl = navCtrl;
        this.userData = userData;
        this.events = events;
        this.alertCtrl = alertCtrl;
        this.viewMode = "date";
        events.subscribe('add_permission', function (email) {
            _this.ngOnInit();
        });
    }
    ComparisonPage.prototype.ngOnInit = function () {
        return __awaiter(this, void 0, void 0, function () {
            var headers;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.userData.getUsername().then(function (username) {
                            console.log(username);
                            _this.email = username;
                        })];
                    case 1:
                        _a.sent();
                        headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
                        headers.set('Content-Type', 'application/json');
                        this.http.get('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/get_handshakes?email=' + this.email, { headers: headers }).subscribe(function (data) {
                            console.log(data);
                            if (data['result'] == 'successful') {
                                _this.all_compares = data['data'];
                                _this.all_compares_sort = data['sort_data'];
                            }
                            else {
                                _this.all_compares = [];
                                _this.all_compares_sort = [];
                                // this.alertshow("Server connection error");
                            }
                        }, function (error) {
                            console.log(error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    ComparisonPage.prototype.alertshow = function (msg) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: msg,
                            buttons: [
                                {
                                    text: 'Ok',
                                    handler: function (data) { }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ComparisonPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-comparison',
            template: __webpack_require__(/*! ./comparison.page.html */ "./src/app/comparison/comparison.page.html"),
            styles: [__webpack_require__(/*! ./comparison.page.scss */ "./src/app/comparison/comparison.page.scss")],
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__["UserDataService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Events"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], ComparisonPage);
    return ComparisonPage;
}());



/***/ }),

/***/ "./src/app/permissions/addpermission/addpermission.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/permissions/addpermission/addpermission.module.ts ***!
  \*******************************************************************/
/*! exports provided: AddpermissionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddpermissionPageModule", function() { return AddpermissionPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _addpermission_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./addpermission.page */ "./src/app/permissions/addpermission/addpermission.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _addpermission_page__WEBPACK_IMPORTED_MODULE_5__["AddpermissionPage"]
    }
];
var AddpermissionPageModule = /** @class */ (function () {
    function AddpermissionPageModule() {
    }
    AddpermissionPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_addpermission_page__WEBPACK_IMPORTED_MODULE_5__["AddpermissionPage"]]
        })
    ], AddpermissionPageModule);
    return AddpermissionPageModule;
}());



/***/ }),

/***/ "./src/app/permissions/addpermission/addpermission.page.html":
/*!*******************************************************************!*\
  !*** ./src/app/permissions/addpermission/addpermission.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <div padding>\n      <div padding text-center item-text style=\"display: flex;  justify-content: center;  align-items: center; padding-top: 15px\">\n        <div style=\"display: grid; text-align: right\">  \n          <ion-label class=\"title\">Permissons</ion-label>\n          <ion-label>add permisson</ion-label>\n        </div>\n          <ion-icon class=\"title_icon\" name=\"unlock\"></ion-icon>\n      </div>\n\n      <div padding text-center item-text class=\"permission_div\">\n          <div padding class=\"add_permission_input\">\n              <h6 stacked >User's account name or email</h6>\n              <ion-input type=\"email\" placeholder=\"example@example.com\" [(ngModel)] = \"compare_email\"></ion-input>\n          </div>\n\n          <div padding class=\"add_permission_input\" style=\"margin-top: 20px\">\n              <h6 stacked >Code</h6>\n              <ion-input type=\"text\" placeholder=\"code\" [(ngModel)] = \"compare_code\"></ion-input>\n          </div>\n\n          <div padding>\n            <ion-label class=\"select_description\">select the traits you would like to share</ion-label>\n          </div>\n\n          <div  style=\"flex: row\" >\n              <ion-row>\n                  <ion-col col-4> \n                      <button class=\"sort_button\" (click)= \"sort_trait()\">SORT BY ALPHABETA</button>\n                  </ion-col>\n                \n                  <ion-col col-8 style=\"display: inline-flex;\">\n                      <button style=\"margin-right: 5px;\" class=\"select_all\" (click)= \"select_all()\">Select All</button>\n                      <button class=\"select_all\" (click)= \"deselect_all()\">Deselect All</button>\n                  </ion-col>\n              </ion-row>\n          </div>\n            <div style=\"margin-top: 10px; width: 100%; height: 2px; background-color: #3c3c3c91;\">\n            </div>\n          <div style=\"margin-top: 20px;\">\n            <ion-row >\n                <div *ngFor=\"let trait of this.all_traits;  let i = index\"  style=\"margin: auto; margin-top: 5px\" >\n                    <button size=\"small\" expand=\"block\" \n                    (click)= \"btnclick(i)\"\n                    [class] = \"trait.enable == true ? 'focus' : 'unfocus'\">{{trait.traits}}</button>\n                </div>\n            </ion-row>\n          </div>\n        </div>\n        <div padding-top>\n          <ion-button size=\"default\" (click)=\"save()\" expand=\"block\" >DONE</ion-button>\n        </div>\n    \n    </div>\n  </ion-content>"

/***/ }),

/***/ "./src/app/permissions/addpermission/addpermission.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/permissions/addpermission/addpermission.page.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".my-width {\n  width: 40%;\n  margin: auto; }\n"

/***/ }),

/***/ "./src/app/permissions/addpermission/addpermission.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/permissions/addpermission/addpermission.page.ts ***!
  \*****************************************************************/
/*! exports provided: AddpermissionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddpermissionPage", function() { return AddpermissionPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../provider/user-data.service */ "./src/app/provider/user-data.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var AddpermissionPage = /** @class */ (function () {
    function AddpermissionPage(router, http, navCtrl, userData, events, alertCtrl) {
        this.router = router;
        this.http = http;
        this.navCtrl = navCtrl;
        this.userData = userData;
        this.events = events;
        this.alertCtrl = alertCtrl;
        this.compare_traits = [];
    }
    AddpermissionPage.prototype.ngOnInit = function () {
        this.get_all_traits();
        this.getUsername();
    };
    AddpermissionPage.prototype.getUsername = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.userData.getUsername().then(function (username) {
                            // console.log(username);
                            _this.email = username;
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    AddpermissionPage.prototype.get_all_traits = function () {
        var _this = this;
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
        headers.set('Content-Type', 'application/json');
        this.http.get('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/get_all_traits', { headers: headers }).subscribe(function (data) {
            console.log(data);
            if (data['result'] == 'successful') {
                _this.all_traits = data['traits'];
                _this.all_traits_sort = data['traits_sort'];
                // for (let i = 0; i < this.all_traits.length; i++) {
                //   i % 2 == 0 ? this.all_traits[i].enable = true : this.all_traits[i].enable = false;
                // }
            }
            else {
                _this.alertshow("Server connection error");
            }
        }, function (error) {
            console.log(error);
        });
    };
    AddpermissionPage.prototype.btnclick = function (index) {
        this.all_traits[index].enable = !this.all_traits[index].enable;
        // this.all_traits_sort[index].enable = !this.all_traits_sort[index].enable;
        console.log(this.all_traits[index].traits);
    };
    AddpermissionPage.prototype.save = function () {
        var _this = this;
        this.compare_traits = [];
        for (var i = 0; i < this.all_traits.length; i++) {
            this.all_traits[i].enable == true ? this.compare_traits.push(this.all_traits[i].traits) : console.log("d");
        }
        if (this.compare_email == undefined || this.compare_code == undefined) {
            this.alertshow("Please Insert Email and Code");
        }
        else {
            if (this.compare_traits.length == 0) {
                this.alertshow("Please Select one more traits");
            }
            else {
                this.add_permission_user = {
                    "email": this.email,
                    "compare_email": this.compare_email,
                    "compare_traits": this.compare_traits,
                    "compare_code": this.compare_code
                };
                console.log(this.add_permission_user);
                var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
                headers.set('Content-Type', 'application/json');
                this.http.post('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/add_permission', this.add_permission_user, { headers: headers }).subscribe(function (data) {
                    console.log(data);
                    if (data['result'] == 'successful') {
                        // this.all_traits = data['traits'];
                        // this.alertshow();
                        _this.alertshow("Add Permission Successfully");
                        _this.events.publish('add_permission', _this.email);
                    }
                    else if (data['result'] == 'Invaild code') {
                        _this.alertshow("Invalid Permission Code.");
                    }
                    else {
                        _this.alertshow("Server connection error");
                    }
                }, function (error) {
                    console.log(error);
                });
            }
        }
    };
    AddpermissionPage.prototype.alertshow = function (msg) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: msg,
                            buttons: [
                                {
                                    text: 'Ok',
                                    handler: function (data) { }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    AddpermissionPage.prototype.sort_trait = function () {
        // for (let i = 0; i < this.all_traits.length; i++) {
        //   this.all_traits[i].enable = true;
        //   // this.all_traits_sort[i].enable = true;
        // }
        // this.all_traits.sort('traits');
        this.all_traits = this.all_traits_sort;
    };
    AddpermissionPage.prototype.deselect_all = function () {
        // console.log("deselect");
        for (var i = 0; i < this.all_traits.length; i++) {
            this.all_traits[i].enable = false;
            // this.all_traits_sort[i].enable = true;
        }
    };
    AddpermissionPage.prototype.select_all = function () {
        // console.log("sdf");
        for (var i = 0; i < this.all_traits.length; i++) {
            this.all_traits[i].enable = true;
            // this.all_traits_sort[i].enable = true;
        }
    };
    AddpermissionPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-addpermission',
            template: __webpack_require__(/*! ./addpermission.page.html */ "./src/app/permissions/addpermission/addpermission.page.html"),
            styles: [__webpack_require__(/*! ./addpermission.page.scss */ "./src/app/permissions/addpermission/addpermission.page.scss")],
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__["UserDataService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Events"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], AddpermissionPage);
    return AddpermissionPage;
}());



/***/ }),

/***/ "./src/app/permissions/permissioncode/permissioncode.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/permissions/permissioncode/permissioncode.module.ts ***!
  \*********************************************************************/
/*! exports provided: PermissioncodePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermissioncodePageModule", function() { return PermissioncodePageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _permissioncode_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./permissioncode.page */ "./src/app/permissions/permissioncode/permissioncode.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _permissioncode_page__WEBPACK_IMPORTED_MODULE_5__["PermissioncodePage"]
    }
];
var PermissioncodePageModule = /** @class */ (function () {
    function PermissioncodePageModule() {
    }
    PermissioncodePageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_permissioncode_page__WEBPACK_IMPORTED_MODULE_5__["PermissioncodePage"]]
        })
    ], PermissioncodePageModule);
    return PermissioncodePageModule;
}());



/***/ }),

/***/ "./src/app/permissions/permissioncode/permissioncode.page.html":
/*!*********************************************************************!*\
  !*** ./src/app/permissions/permissioncode/permissioncode.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content padding>\n    <div padding text-center item-text style=\"display: flex;  justify-content: center;  align-items: center; padding-top: 45px\">\n        <ion-label class=\"title\">Permissons</ion-label>\n        <ion-icon class=\"title_icon\" name=\"unlock\"></ion-icon>\n    </div>\n\n    <div padding>\n        <div padding  class=\"generate_codepan\">\n            <h2 stacked style=\"color: #3F5584; opacity: 1;\">{{permission_code}}</h2>\n            <h5 stacked style=\"font-size: 12px; margin-top: 5px; margin-bottom: 1px; color: #3F5584; opacity: 0.6;\">your special code</h5>\n        </div>\n    </div>\n\n    <div padding>\n        <ion-button size=\"default\" (click)=\"generate_code()\" expand=\"block\" >Generate Code</ion-button>\n    </div>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/permissions/permissioncode/permissioncode.page.scss":
/*!*********************************************************************!*\
  !*** ./src/app/permissions/permissioncode/permissioncode.page.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/permissions/permissioncode/permissioncode.page.ts":
/*!*******************************************************************!*\
  !*** ./src/app/permissions/permissioncode/permissioncode.page.ts ***!
  \*******************************************************************/
/*! exports provided: PermissioncodePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermissioncodePage", function() { return PermissioncodePage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../provider/user-data.service */ "./src/app/provider/user-data.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var PermissioncodePage = /** @class */ (function () {
    function PermissioncodePage(router, http, navCtrl, userData, alertCtrl) {
        this.router = router;
        this.http = http;
        this.navCtrl = navCtrl;
        this.userData = userData;
        this.alertCtrl = alertCtrl;
    }
    PermissioncodePage.prototype.ngOnInit = function () {
        return __awaiter(this, void 0, void 0, function () {
            var headers;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.userData.getUsername().then(function (username) {
                            console.log(username);
                            _this.email = username;
                        })];
                    case 1:
                        _a.sent();
                        headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
                        headers.set('Content-Type', 'application/json');
                        this.http.get('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/get_permission_code?email=' + this.email, { headers: headers }).subscribe(function (data) {
                            // console.log(data);
                            if (data['result'] == 'successful') {
                                // this.question = data['question'].questions;
                                _this.permission_code = data['code'];
                            }
                            else {
                                _this.alertshow("Server connection error");
                            }
                        }, function (error) {
                            console.log(error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    PermissioncodePage.prototype.generate_code = function () {
        var _this = this;
        this.alertshow("the connection will be deleted, do you want to continue?");
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
        headers.set('Content-Type', 'application/json');
        this.http.get('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/generate_code?email=' + this.email, { headers: headers }).subscribe(function (data) {
            console.log(data);
            if (data['result'] == 'successful') {
                // this.question = data['question'].questions;
                _this.permission_code = data['code'];
            }
            else {
                _this.alertshow("Server connection error");
            }
        }, function (error) {
            console.log(error);
        });
    };
    PermissioncodePage.prototype.alertshow = function (msg) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: msg,
                            buttons: [
                                {
                                    text: 'Ok',
                                    handler: function (data) { }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PermissioncodePage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-permissioncode',
            template: __webpack_require__(/*! ./permissioncode.page.html */ "./src/app/permissions/permissioncode/permissioncode.page.html"),
            styles: [__webpack_require__(/*! ./permissioncode.page.scss */ "./src/app/permissions/permissioncode/permissioncode.page.scss")],
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__["UserDataService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], PermissioncodePage);
    return PermissioncodePage;
}());



/***/ }),

/***/ "./src/app/permissions/permissions.module.ts":
/*!***************************************************!*\
  !*** ./src/app/permissions/permissions.module.ts ***!
  \***************************************************/
/*! exports provided: PermissionsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermissionsPageModule", function() { return PermissionsPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _permissions_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./permissions.page */ "./src/app/permissions/permissions.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _permissions_page__WEBPACK_IMPORTED_MODULE_5__["PermissionsPage"]
    }
];
var PermissionsPageModule = /** @class */ (function () {
    function PermissionsPageModule() {
    }
    PermissionsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_permissions_page__WEBPACK_IMPORTED_MODULE_5__["PermissionsPage"]]
        })
    ], PermissionsPageModule);
    return PermissionsPageModule;
}());



/***/ }),

/***/ "./src/app/permissions/permissions.page.html":
/*!***************************************************!*\
  !*** ./src/app/permissions/permissions.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-content padding>\n        <div padding text-center item-text style=\"display: flex;  justify-content: center;  align-items: center; padding-top: 45px\">\n            <ion-label class=\"title\">Permissons</ion-label>\n            <ion-icon  class=\"title_icon\" name=\"unlock\"></ion-icon>\n        </div>\n\n      <div padding>\n          <ion-button size=\"default\" href=\"/tab/(permissions:addpermission)\" expand=\"block\">ADD PERMISSION</ion-button>\n      </div>\n      <div padding>\n          <ion-button size=\"default\" href=\"/tab/(permissions:revokepermission)\" expand=\"block\">REVOKE PERMISSION</ion-button>\n      </div>\n\n      <div padding>\n          <ion-button size=\"default\" href=\"/tab/(permissions:permissioncode)\" expand=\"block\">PERMISSION CODE</ion-button>\n      </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/permissions/permissions.page.scss":
/*!***************************************************!*\
  !*** ./src/app/permissions/permissions.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/permissions/permissions.page.ts":
/*!*************************************************!*\
  !*** ./src/app/permissions/permissions.page.ts ***!
  \*************************************************/
/*! exports provided: PermissionsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermissionsPage", function() { return PermissionsPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var PermissionsPage = /** @class */ (function () {
    function PermissionsPage() {
    }
    PermissionsPage.prototype.ngOnInit = function () {
    };
    PermissionsPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-permissions',
            template: __webpack_require__(/*! ./permissions.page.html */ "./src/app/permissions/permissions.page.html"),
            styles: [__webpack_require__(/*! ./permissions.page.scss */ "./src/app/permissions/permissions.page.scss")],
        }),
        __metadata("design:paramtypes", [])
    ], PermissionsPage);
    return PermissionsPage;
}());



/***/ }),

/***/ "./src/app/permissions/revokepermission/revokepermission.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/permissions/revokepermission/revokepermission.module.ts ***!
  \*************************************************************************/
/*! exports provided: RevokepermissionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RevokepermissionPageModule", function() { return RevokepermissionPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _revokepermission_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./revokepermission.page */ "./src/app/permissions/revokepermission/revokepermission.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _revokepermission_page__WEBPACK_IMPORTED_MODULE_5__["RevokepermissionPage"]
    }
];
var RevokepermissionPageModule = /** @class */ (function () {
    function RevokepermissionPageModule() {
    }
    RevokepermissionPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_revokepermission_page__WEBPACK_IMPORTED_MODULE_5__["RevokepermissionPage"]]
        })
    ], RevokepermissionPageModule);
    return RevokepermissionPageModule;
}());



/***/ }),

/***/ "./src/app/permissions/revokepermission/revokepermission.page.html":
/*!*************************************************************************!*\
  !*** ./src/app/permissions/revokepermission/revokepermission.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content padding>\n    <div>\n        <div padding text-center item-text style=\"display: flex;  justify-content: center;  align-items: center; padding-top: 15px\">\n            <div style=\"display: grid; text-align: right\">  \n                <ion-label class=\"title\">Permissons</ion-label>\n                <ion-label>revoke permisson</ion-label>\n            </div>\n            <ion-icon  class=\"title_icon\" name=\"unlock\"></ion-icon>\n        </div>\n        \n        <div padding-top>\n            <ion-segment [(ngModel)]=\"viewMode\">\n            <ion-segment-button value=\"date\">\n                <ion-label>DATE SHARED</ion-label>\n        \n            </ion-segment-button>\n            <ion-segment-button value=\"alphabet\">\n                <ion-label>ALPHABET</ion-label>\n            </ion-segment-button>\n            </ion-segment>\n        </div>\n\n        <div *ngIf=\"viewMode === 'date'\" padding-top style=\"border-radius: 10px\">\n            <ion-item expand=\"block\"  *ngFor=\"let user of this.all_handshake;  let i = index\">\n                <ion-label>{{user.email}}</ion-label>\n                <ion-select [(ngModel)]=\"user.ngmodel_1\" (ionChange)=\"onSelectChange(user.name, user.ngmodel_1, i)\">\n                    <ion-select-option  \n                        *ngFor=\"let trait_one of this.user.compare_traits;  let i = index\" \n                        [value]=\"trait_one\">{{trait_one}}</ion-select-option>\n                </ion-select>\n            </ion-item>\n\n        </div>\n\n\n\n\n        <div *ngIf=\"viewMode === 'alphabet'\" padding-top style=\"border-radius: 10px\">\n            <ion-item expand=\"block\" *ngFor=\"let user of this.all_handshake_sort;  let i = index\">\n                <ion-label>{{user.email}}</ion-label>\n                <ion-select [(ngModel)]=\"user.ngmodel_2\" (ionChange)=\"onSelectChange(user.name, user.ngmodel_2, i)\">\n                    <ion-select-option  \n                        *ngFor=\"let trait of this.user.compare_traits;  let i = index\" \n                        [value]=\"trait\">{{trait}}</ion-select-option>\n                </ion-select>\n            </ion-item>\n    \n        </div>\n    </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/permissions/revokepermission/revokepermission.page.scss":
/*!*************************************************************************!*\
  !*** ./src/app/permissions/revokepermission/revokepermission.page.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-segment-button {\n  font-size: unset;\n  height: 37px;\n  --border-radius: 10px; }\n\nion-segment {\n  --background-checked: #fafafa;\n  --color: #fafafa;\n  --color-checked: #2B2A2F;\n  --border-color-checked: #fafafa; }\n\nion-item {\n  --inner-border-width: 0;\n  --border-width: 0 0 1px 0;\n  --border-color: red;\n  border-color: red;\n  --ion-color-shade: #f2f2f2 !important; }\n\nion-select {\n  font-size: 0px; }\n"

/***/ }),

/***/ "./src/app/permissions/revokepermission/revokepermission.page.ts":
/*!***********************************************************************!*\
  !*** ./src/app/permissions/revokepermission/revokepermission.page.ts ***!
  \***********************************************************************/
/*! exports provided: RevokepermissionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RevokepermissionPage", function() { return RevokepermissionPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../provider/user-data.service */ "./src/app/provider/user-data.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var RevokepermissionPage = /** @class */ (function () {
    function RevokepermissionPage(router, http, navCtrl, userData, events, alertCtrl) {
        var _this = this;
        this.router = router;
        this.http = http;
        this.navCtrl = navCtrl;
        this.userData = userData;
        this.events = events;
        this.alertCtrl = alertCtrl;
        this.viewMode = 'date';
        // this.all_handshake[1].delete_trait = 'happy';
        events.subscribe('add_permission', function (email) {
            _this.ngOnInit();
        });
    }
    RevokepermissionPage.prototype.ngOnInit = function () {
        return __awaiter(this, void 0, void 0, function () {
            var headers;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.userData.getUsername().then(function (username) {
                            console.log(username);
                            _this.email = username;
                        })];
                    case 1:
                        _a.sent();
                        headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
                        headers.set('Content-Type', 'application/json');
                        this.http.get('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/get_handshakes?email=' + this.email, { headers: headers }).subscribe(function (data) {
                            console.log(data);
                            if (data['result'] == 'successful') {
                                _this.all_handshake = data['data'];
                                _this.all_handshake_sort = data['sort_data'];
                                console.log(_this.all_handshake[0].email);
                            }
                            else if (data['result'] == "no connection people") {
                                _this.alertshow("You don't have any connection");
                                // this.ngOnInit();
                            }
                            else {
                                _this.all_handshake = [];
                                _this.alertshow("Server connection error");
                            }
                        }, function (error) {
                            console.log(error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    RevokepermissionPage.prototype.onSelectChange = function (name, triat, index) {
        var _this = this;
        console.log(name, triat, index, this.all_handshake[index].email, this.email);
        if (triat !== undefined) {
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
            headers.set('Content-Type', 'application/json');
            this.http.get('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/delete_compare_traits?email=' + this.email + '&compare_email=' + this.all_handshake[index].email + '&delete_trait=' + triat, { headers: headers }).subscribe(function (data) {
                console.log(data);
                if (data['result'] == 'successful') {
                    // this.refresh = this.all_handshake;
                    // this.all_handshake = [];
                    // this.all_handshake this.refresh; 
                    // this.all_handshake[index].compare_traits = data['compare_traits'];
                    // this.all_handshake_sort[index].compare_traits = data['compare_traits'];
                    _this.ngOnInit();
                }
                else if (data['result'] == "no array") {
                    _this.all_handshake = [];
                    _this.all_handshake_sort = [];
                    // this.ngOnInit();
                }
                else if (data['result'] == "no connection people") {
                    // alert("no connection people");
                    _this.ngOnInit();
                }
                else {
                    // this.alertshow("Server connection failed");
                }
            }, function (error) {
                console.log(error);
            });
        }
        else { }
    };
    RevokepermissionPage.prototype.alertshow = function (msg) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: msg,
                            buttons: [
                                {
                                    text: 'Ok',
                                    handler: function (data) { }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    RevokepermissionPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-revokepermission',
            template: __webpack_require__(/*! ./revokepermission.page.html */ "./src/app/permissions/revokepermission/revokepermission.page.html"),
            styles: [__webpack_require__(/*! ./revokepermission.page.scss */ "./src/app/permissions/revokepermission/revokepermission.page.scss")],
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__["UserDataService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Events"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], RevokepermissionPage);
    return RevokepermissionPage;
}());



/***/ }),

/***/ "./src/app/profile/profile.module.ts":
/*!*******************************************!*\
  !*** ./src/app/profile/profile.module.ts ***!
  \*******************************************/
/*! exports provided: ProfilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function() { return ProfilePageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./profile.page */ "./src/app/profile/profile.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_5__["ProfilePage"]
    }
];
var ProfilePageModule = /** @class */ (function () {
    function ProfilePageModule() {
    }
    ProfilePageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild([{ path: '', component: _profile_page__WEBPACK_IMPORTED_MODULE_5__["ProfilePage"] }])
            ],
            declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_5__["ProfilePage"]]
        })
    ], ProfilePageModule);
    return ProfilePageModule;
}());



/***/ }),

/***/ "./src/app/profile/profile.page.html":
/*!*******************************************!*\
  !*** ./src/app/profile/profile.page.html ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content >\n    <div padding>\n    <div padding text-center item-text style=\"display: flex;  justify-content: center;  align-items: center; padding-top: 45px\">\n        <ion-label class=\"title\">Profile</ion-label>\n        <ion-icon class=\"title_icon\" name=\"md-person\"></ion-icon>\n    </div>\n\n    <div padding-top>\n      <ion-segment [(ngModel)]=\"viewMode\">\n        <ion-segment-button value=\"positive\">\n          <ion-label>Most Positive</ion-label>\n\n        </ion-segment-button>\n        <ion-segment-button value=\"negative\">\n          <ion-label>Most Negative</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n\n    <div *ngIf=\"viewMode === 'positive'\" padding-top style=\"border-radius: 10px\">\n        <div>\n            <ion-item expand=\"block\">\n                <ion-label style=\"font-size: 14px\">TRAIT</ion-label>\n                <h6 style=\"margin-right: 10px; font-size: 14px\" class=\"cs_text\">CS</h6>\n                <h6 style=\"margin-right: 10px; font-size: 14px;  border-radius: 4px; --inner-padding-top: 0px;\" class=\"percent_text\">PERCENT</h6>\n            </ion-item>\n\n            <!-- <ion-item expand=\"block\" color=\"dark\" style=\"\">\n                <ion-label>Happiness</ion-label>\n                <h6 style=\"margin-right: 10px;\">12cs</h6>\n                <h6 style=\"margin-right: 10px; padding: 3px;  background-color: black; border-radius: 4px;\">12%</h6>\n            </ion-item> -->\n\n            <ion-item expand=\"block\" style=\"\" *ngFor=\"let x of this.positive_cs;  let i = index\" >\n                <ion-label>{{x.trait_name}}</ion-label>\n                <h6 style=\"margin-right: 10px;\" class=\"cs_text\">{{x.cs}} CS</h6>\n                <h6 style=\"margin-right: 10px; padding: 3px; font-size: 14px; border-radius: 4px;\" class=\"percent_text\">{{x.percent}}%</h6>\n            </ion-item>\n        </div>\n    </div>\n\n    <div *ngIf=\"viewMode === 'negative'\" padding-top style=\"border-radius: 10px\">\n        <div>\n            <ion-item expand=\"block\" >\n                <ion-label style=\"font-size: 14px\" >TRAIT</ion-label>\n                <h6 style=\"margin-right: 10px; font-size: 14px\" class=\"cs_text\">CS</h6>\n                <h6 style=\"margin-right: 10px; font-size: 14px; border-radius: 4px; --inner-padding-top: 0px;\" class=\"percent_text\">PERCENT</h6>\n            </ion-item>\n\n            <ion-item expand=\"block\" *ngFor=\"let x of this.negative_cs;  let i = index\" >\n                <ion-label>{{x.trait_name}}</ion-label>\n                <h6 style=\"margin-right: 10px;\" class=\"cs_text\">{{x.cs}} CS</h6>\n                <h6 style=\"margin-right: 10px; padding: 3px; font-size: 14px; border-radius: 4px;\" class=\"percent_text\">{{x.percent}}%</h6>\n            </ion-item>\n        </div>\n    </div>\n </div>\n\n</ion-content>"

/***/ }),

/***/ "./src/app/profile/profile.page.scss":
/*!*******************************************!*\
  !*** ./src/app/profile/profile.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-segment-button {\n  font-size: unset;\n  height: 37px;\n  --border-radius: 10px; }\n\nion-segment {\n  --background-checked: #fafafa;\n  --color: #fafafa;\n  --color-checked: #2B2A2F;\n  --border-color-checked: #fafafa; }\n\nion-item {\n  --inner-border-width: 0;\n  --border-width: 0 0 1px 0;\n  --border-color: red;\n  border-color: red;\n  --ion-color-shade: #f2f2f2 !important; }\n"

/***/ }),

/***/ "./src/app/profile/profile.page.ts":
/*!*****************************************!*\
  !*** ./src/app/profile/profile.page.ts ***!
  \*****************************************/
/*! exports provided: ProfilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePage", function() { return ProfilePage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _provider_user_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../provider/user-data.service */ "./src/app/provider/user-data.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var ProfilePage = /** @class */ (function () {
    function ProfilePage(router, http, navCtrl, events, userData, alertCtrl) {
        var _this = this;
        this.router = router;
        this.http = http;
        this.navCtrl = navCtrl;
        this.events = events;
        this.userData = userData;
        this.alertCtrl = alertCtrl;
        this.viewMode = "positive";
        events.subscribe('batch_anwer_done', function (email) {
            _this.ngOnInit();
        });
    }
    ProfilePage.prototype.ngOnInit = function () {
        return __awaiter(this, void 0, void 0, function () {
            var headers;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.userData.getUsername().then(function (username) {
                            console.log(username);
                            _this.email = username;
                        })];
                    case 1:
                        _a.sent();
                        headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
                        headers.set('Content-Type', 'application/json');
                        this.http.get('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/positive_cs?email=' + this.email, { headers: headers }).subscribe(function (data) {
                            console.log(data);
                            if (data['result'] == 'success') {
                                _this.positive_cs = data['person_cs_positive'];
                                _this.negative_cs = data['person_cs_negative'];
                            }
                            else if (data['result'] == 'failed') {
                                _this.alertshow("You don't have any Personality Test.");
                            }
                            else {
                                _this.alertshow("Server Connection Failed");
                            }
                        }, function (error) {
                            console.log(error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    ProfilePage.prototype.alertshow = function (msg) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: msg,
                            buttons: [
                                {
                                    text: 'Ok',
                                    handler: function (data) { }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProfilePage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-profile',
            template: __webpack_require__(/*! ./profile.page.html */ "./src/app/profile/profile.page.html"),
            styles: [__webpack_require__(/*! ./profile.page.scss */ "./src/app/profile/profile.page.scss")],
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Events"],
            _provider_user_data_service__WEBPACK_IMPORTED_MODULE_4__["UserDataService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]])
    ], ProfilePage);
    return ProfilePage;
}());



/***/ }),

/***/ "./src/app/question/question.module.ts":
/*!*********************************************!*\
  !*** ./src/app/question/question.module.ts ***!
  \*********************************************/
/*! exports provided: QuestionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QuestionPageModule", function() { return QuestionPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _question_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./question.page */ "./src/app/question/question.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _question_page__WEBPACK_IMPORTED_MODULE_5__["QuestionPage"]
    }
];
var QuestionPageModule = /** @class */ (function () {
    function QuestionPageModule() {
    }
    QuestionPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild([{ path: '', component: _question_page__WEBPACK_IMPORTED_MODULE_5__["QuestionPage"] }])
            ],
            declarations: [_question_page__WEBPACK_IMPORTED_MODULE_5__["QuestionPage"]]
        })
    ], QuestionPageModule);
    return QuestionPageModule;
}());



/***/ }),

/***/ "./src/app/question/question.page.html":
/*!*********************************************!*\
  !*** ./src/app/question/question.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content padding>\n  <div padding text-center item-text style=\"display: flex;  justify-content: center;  align-items: center; padding-top: 45px\">\n    <ion-label class=\"title\">Questions</ion-label>\n    <ion-icon class=\"title_icon\" name=\"md-help\"></ion-icon>\n  </div>\n\n  <div padding style=\"margin-top: 150px\">\n      <ion-button size=\"large\" (click)=\"start()\" expand=\"block\" >{{text}}</ion-button>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/question/question.page.scss":
/*!*********************************************!*\
  !*** ./src/app/question/question.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-item {\n  --inner-border-width: 0px; }\n\nbutton {\n  color: white;\n  height: 115px;\n  width: 100%;\n  outline: unset;\n  border-radius: 10px;\n  font-size: 20px;\n  font-weight: bold;\n  background-color: #232227; }\n\nbutton :focus {\n    background-color: #fafafa; }\n\nion-button {\n  padding: inherit;\n  font-size: x-large;\n  --height: 100px;\n  font-weight: bold; }\n"

/***/ }),

/***/ "./src/app/question/question.page.ts":
/*!*******************************************!*\
  !*** ./src/app/question/question.page.ts ***!
  \*******************************************/
/*! exports provided: QuestionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QuestionPage", function() { return QuestionPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/user-data.service */ "./src/app/provider/user-data.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var QuestionPage = /** @class */ (function () {
    function QuestionPage(router, activateRoute, http, userData) {
        this.router = router;
        this.activateRoute = activateRoute;
        this.http = http;
        this.userData = userData;
        this.state = 0;
        this.text = "Start answer";
        this.flag = false;
    }
    QuestionPage.prototype.ngOnInit = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    QuestionPage.prototype.start = function () {
        var _this = this;
        this.router.navigateByUrl("/answer");
        setTimeout(function () {
            _this.text = "Continue answer";
        }, 5000);
        // this.router.navigateByUrl("tab/(question:question)")
        // const headers = new HttpHeaders();
        // headers.set('Content-Type', 'application/json');
        // this.http.post('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/user/login',this.user, {headers: headers}).subscribe(data => {
        // console.log(data);
        // }, 
        // error => {
        // console.log(error);
        // })
    };
    QuestionPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-question',
            template: __webpack_require__(/*! ./question.page.html */ "./src/app/question/question.page.html"),
            styles: [__webpack_require__(/*! ./question.page.scss */ "./src/app/question/question.page.scss")],
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__["UserDataService"]])
    ], QuestionPage);
    return QuestionPage;
}());



/***/ }),

/***/ "./src/app/settings/demographics/demographics.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/settings/demographics/demographics.module.ts ***!
  \**************************************************************/
/*! exports provided: DemographicsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemographicsPageModule", function() { return DemographicsPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _demographics_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./demographics.page */ "./src/app/settings/demographics/demographics.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _demographics_page__WEBPACK_IMPORTED_MODULE_5__["DemographicsPage"]
    }
];
var DemographicsPageModule = /** @class */ (function () {
    function DemographicsPageModule() {
    }
    DemographicsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_demographics_page__WEBPACK_IMPORTED_MODULE_5__["DemographicsPage"]]
        })
    ], DemographicsPageModule);
    return DemographicsPageModule;
}());



/***/ }),

/***/ "./src/app/settings/demographics/demographics.page.html":
/*!**************************************************************!*\
  !*** ./src/app/settings/demographics/demographics.page.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <div padding>\n      <div padding text-center item-text style=\"display: flex;  justify-content: center;  align-items: center; padding-top: 15px\">\n        <div style=\"display: grid; text-align: right\">  \n          <ion-label class=\"title\">Settings</ion-label>\n          <ion-label>Demographics</ion-label>\n        </div>\n          <ion-icon class=\"title_icon\" name=\"md-settings\"></ion-icon>\n      </div>\n  </div>\n\n  <div >\n      <div padding>\n          <ion-item expand=\"block\" >\n              <ion-label>YOUR AGE</ion-label>\n              <ion-select [(ngModel)]=\"selected_age\" class=\"ion_select_color\">\n                  <ion-select-option  *ngFor=\"let x of this.ages;  let i = index\" [value]=index [selected]=\"selected\">{{x}}</ion-select-option>\n                  <!-- <ion-select-option value=\"no\">NO</ion-select-option> -->\n              </ion-select>\n          </ion-item>\n\n          <ion-item   expand=\"block\">\n              <ion-label>COUNTRY OF BIRTH</ion-label>\n              <ion-select [(ngModel)]=\"selected_country\" class=\"ion_select_color\">\n                  <ion-select-option *ngFor=\"let country of this.countries\" [value] = \"country.name\" [selected]=\"selected\" >{{country.name}}</ion-select-option>\n              </ion-select>\n          </ion-item>\n\n          <ion-item   expand=\"block\" >\n              <ion-label>COUNTRY OF RESIDENCE</ion-label>\n              <ion-select [(ngModel)]=\"selected_residence_country\" class=\"ion_select_color\">\n                <ion-select-option *ngFor=\"let country of this.countries\" [value] = \"country.name\" [selected]=\"selected\" >{{country.name}}</ion-select-option>\n              </ion-select>\n          </ion-item>\n\n          <ion-item  expand=\"block\" >\n              <ion-label>YOUR GENDER</ion-label>\n              <ion-select [(ngModel)]=\"gender\" class=\"ion_select_color\">\n                  <ion-select-option value=\"male\">Male</ion-select-option>\n                  <ion-select-option value=\"female\">Female</ion-select-option>\n              </ion-select>\n          </ion-item>\n      </div>\n\n    <div padding>\n      <ion-button (click)= \"save()\" size=\"default\" expand=\"block\"  >SAVE</ion-button>\n    </div>\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/settings/demographics/demographics.page.scss":
/*!**************************************************************!*\
  !*** ./src/app/settings/demographics/demographics.page.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-item {\n  --ion-color-shade: #fafafa !important; }\n\nion-select {\n  color: white; }\n\nion-label {\n  font-size: 16px;\n  font-weight: bold; }\n"

/***/ }),

/***/ "./src/app/settings/demographics/demographics.page.ts":
/*!************************************************************!*\
  !*** ./src/app/settings/demographics/demographics.page.ts ***!
  \************************************************************/
/*! exports provided: DemographicsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemographicsPage", function() { return DemographicsPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _provider_user_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../provider/user-data.service */ "./src/app/provider/user-data.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var DemographicsPage = /** @class */ (function () {
    function DemographicsPage(router, alertCtrl, navCtrl, http, userData) {
        this.router = router;
        this.alertCtrl = alertCtrl;
        this.navCtrl = navCtrl;
        this.http = http;
        this.userData = userData;
        this.countries = [
            {
                "name": "Afghanistan",
                "code": "AF"
            },
            {
                "name": "Åland Islands",
                "code": "AX"
            },
            {
                "name": "Albania",
                "code": "AL"
            },
            {
                "name": "Algeria",
                "code": "DZ"
            },
            {
                "name": "American Samoa",
                "code": "AS"
            },
            {
                "name": "AndorrA",
                "code": "AD"
            },
            {
                "name": "Angola",
                "code": "AO"
            },
            {
                "name": "Anguilla",
                "code": "AI"
            },
            {
                "name": "Antarctica",
                "code": "AQ"
            },
            {
                "name": "Antigua and Barbuda",
                "code": "AG"
            },
            {
                "name": "Argentina",
                "code": "AR"
            },
            {
                "name": "Armenia",
                "code": "AM"
            },
            {
                "name": "Aruba",
                "code": "AW"
            },
            {
                "name": "Australia",
                "code": "AU"
            },
            {
                "name": "Austria",
                "code": "AT"
            },
            {
                "name": "Azerbaijan",
                "code": "AZ"
            },
            {
                "name": "Bahamas",
                "code": "BS"
            },
            {
                "name": "Bahrain",
                "code": "BH"
            },
            {
                "name": "Bangladesh",
                "code": "BD"
            },
            {
                "name": "Barbados",
                "code": "BB"
            },
            {
                "name": "Belarus",
                "code": "BY"
            },
            {
                "name": "Belgium",
                "code": "BE"
            },
            {
                "name": "Belize",
                "code": "BZ"
            },
            {
                "name": "Benin",
                "code": "BJ"
            },
            {
                "name": "Bermuda",
                "code": "BM"
            },
            {
                "name": "Bhutan",
                "code": "BT"
            },
            {
                "name": "Bolivia",
                "code": "BO"
            },
            {
                "name": "Bosnia and Herzegovina",
                "code": "BA"
            },
            {
                "name": "Botswana",
                "code": "BW"
            },
            {
                "name": "Bouvet Island",
                "code": "BV"
            },
            {
                "name": "Brazil",
                "code": "BR"
            },
            {
                "name": "British Indian Ocean Territory",
                "code": "IO"
            },
            {
                "name": "Brunei Darussalam",
                "code": "BN"
            },
            {
                "name": "Bulgaria",
                "code": "BG"
            },
            {
                "name": "Burkina Faso",
                "code": "BF"
            },
            {
                "name": "Burundi",
                "code": "BI"
            },
            {
                "name": "Cambodia",
                "code": "KH"
            },
            {
                "name": "Cameroon",
                "code": "CM"
            },
            {
                "name": "Canada",
                "code": "CA"
            },
            {
                "name": "Cape Verde",
                "code": "CV"
            },
            {
                "name": "Cayman Islands",
                "code": "KY"
            },
            {
                "name": "Central African Republic",
                "code": "CF"
            },
            {
                "name": "Chad",
                "code": "TD"
            },
            {
                "name": "Chile",
                "code": "CL"
            },
            {
                "name": "China",
                "code": "CN"
            },
            {
                "name": "Christmas Island",
                "code": "CX"
            },
            {
                "name": "Cocos (Keeling) Islands",
                "code": "CC"
            },
            {
                "name": "Colombia",
                "code": "CO"
            },
            {
                "name": "Comoros",
                "code": "KM"
            },
            {
                "name": "Congo",
                "code": "CG"
            },
            {
                "name": "Congo, The Democratic Republic of the",
                "code": "CD"
            },
            {
                "name": "Cook Islands",
                "code": "CK"
            },
            {
                "name": "Costa Rica",
                "code": "CR"
            },
            {
                "name": "Cote D\"Ivoire",
                "code": "CI"
            },
            {
                "name": "Croatia",
                "code": "HR"
            },
            {
                "name": "Cuba",
                "code": "CU"
            },
            {
                "name": "Cyprus",
                "code": "CY"
            },
            {
                "name": "Czech Republic",
                "code": "CZ"
            },
            {
                "name": "Denmark",
                "code": "DK"
            },
            {
                "name": "Djibouti",
                "code": "DJ"
            },
            {
                "name": "Dominica",
                "code": "DM"
            },
            {
                "name": "Dominican Republic",
                "code": "DO"
            },
            {
                "name": "Ecuador",
                "code": "EC"
            },
            {
                "name": "Egypt",
                "code": "EG"
            },
            {
                "name": "El Salvador",
                "code": "SV"
            },
            {
                "name": "Equatorial Guinea",
                "code": "GQ"
            },
            {
                "name": "Eritrea",
                "code": "ER"
            },
            {
                "name": "Estonia",
                "code": "EE"
            },
            {
                "name": "Ethiopia",
                "code": "ET"
            },
            {
                "name": "Falkland Islands (Malvinas)",
                "code": "FK"
            },
            {
                "name": "Faroe Islands",
                "code": "FO"
            },
            {
                "name": "Fiji",
                "code": "FJ"
            },
            {
                "name": "Finland",
                "code": "FI"
            },
            {
                "name": "France",
                "code": "FR"
            },
            {
                "name": "French Guiana",
                "code": "GF"
            },
            {
                "name": "French Polynesia",
                "code": "PF"
            },
            {
                "name": "French Southern Territories",
                "code": "TF"
            },
            {
                "name": "Gabon",
                "code": "GA"
            },
            {
                "name": "Gambia",
                "code": "GM"
            },
            {
                "name": "Georgia",
                "code": "GE"
            },
            {
                "name": "Germany",
                "code": "DE"
            },
            {
                "name": "Ghana",
                "code": "GH"
            },
            {
                "name": "Gibraltar",
                "code": "GI"
            },
            {
                "name": "Greece",
                "code": "GR"
            },
            {
                "name": "Greenland",
                "code": "GL"
            },
            {
                "name": "Grenada",
                "code": "GD"
            },
            {
                "name": "Guadeloupe",
                "code": "GP"
            },
            {
                "name": "Guam",
                "code": "GU"
            },
            {
                "name": "Guatemala",
                "code": "GT"
            },
            {
                "name": "Guernsey",
                "code": "GG"
            },
            {
                "name": "Guinea",
                "code": "GN"
            },
            {
                "name": "Guinea-Bissau",
                "code": "GW"
            },
            {
                "name": "Guyana",
                "code": "GY"
            },
            {
                "name": "Haiti",
                "code": "HT"
            },
            {
                "name": "Heard Island and Mcdonald Islands",
                "code": "HM"
            },
            {
                "name": "Holy See (Vatican City State)",
                "code": "VA"
            },
            {
                "name": "Honduras",
                "code": "HN"
            },
            {
                "name": "Hong Kong",
                "code": "HK"
            },
            {
                "name": "Hungary",
                "code": "HU"
            },
            {
                "name": "Iceland",
                "code": "IS"
            },
            {
                "name": "India",
                "code": "IN"
            },
            {
                "name": "Indonesia",
                "code": "ID"
            },
            {
                "name": "Iran, Islamic Republic Of",
                "code": "IR"
            },
            {
                "name": "Iraq",
                "code": "IQ"
            },
            {
                "name": "Ireland",
                "code": "IE"
            },
            {
                "name": "Isle of Man",
                "code": "IM"
            },
            {
                "name": "Israel",
                "code": "IL"
            },
            {
                "name": "Italy",
                "code": "IT"
            },
            {
                "name": "Jamaica",
                "code": "JM"
            },
            {
                "name": "Japan",
                "code": "JP"
            },
            {
                "name": "Jersey",
                "code": "JE"
            },
            {
                "name": "Jordan",
                "code": "JO"
            },
            {
                "name": "Kazakhstan",
                "code": "KZ"
            },
            {
                "name": "Kenya",
                "code": "KE"
            },
            {
                "name": "Kiribati",
                "code": "KI"
            },
            {
                "name": "Korea, Democratic People\"S Republic of",
                "code": "KP"
            },
            {
                "name": "Korea, Republic of",
                "code": "KR"
            },
            {
                "name": "Kuwait",
                "code": "KW"
            },
            {
                "name": "Kyrgyzstan",
                "code": "KG"
            },
            {
                "name": "Lao People\"S Democratic Republic",
                "code": "LA"
            },
            {
                "name": "Latvia",
                "code": "LV"
            },
            {
                "name": "Lebanon",
                "code": "LB"
            },
            {
                "name": "Lesotho",
                "code": "LS"
            },
            {
                "name": "Liberia",
                "code": "LR"
            },
            {
                "name": "Libyan Arab Jamahiriya",
                "code": "LY"
            },
            {
                "name": "Liechtenstein",
                "code": "LI"
            },
            {
                "name": "Lithuania",
                "code": "LT"
            },
            {
                "name": "Luxembourg",
                "code": "LU"
            },
            {
                "name": "Macao",
                "code": "MO"
            },
            {
                "name": "Macedonia, The Former Yugoslav Republic of",
                "code": "MK"
            },
            {
                "name": "Madagascar",
                "code": "MG"
            },
            {
                "name": "Malawi",
                "code": "MW"
            },
            {
                "name": "Malaysia",
                "code": "MY"
            },
            {
                "name": "Maldives",
                "code": "MV"
            },
            {
                "name": "Mali",
                "code": "ML"
            },
            {
                "name": "Malta",
                "code": "MT"
            },
            {
                "name": "Marshall Islands",
                "code": "MH"
            },
            {
                "name": "Martinique",
                "code": "MQ"
            },
            {
                "name": "Mauritania",
                "code": "MR"
            },
            {
                "name": "Mauritius",
                "code": "MU"
            },
            {
                "name": "Mayotte",
                "code": "YT"
            },
            {
                "name": "Mexico",
                "code": "MX"
            },
            {
                "name": "Micronesia, Federated States of",
                "code": "FM"
            },
            {
                "name": "Moldova, Republic of",
                "code": "MD"
            },
            {
                "name": "Monaco",
                "code": "MC"
            },
            {
                "name": "Mongolia",
                "code": "MN"
            },
            {
                "name": "Montserrat",
                "code": "MS"
            },
            {
                "name": "Morocco",
                "code": "MA"
            },
            {
                "name": "Mozambique",
                "code": "MZ"
            },
            {
                "name": "Myanmar",
                "code": "MM"
            },
            {
                "name": "Namibia",
                "code": "NA"
            },
            {
                "name": "Nauru",
                "code": "NR"
            },
            {
                "name": "Nepal",
                "code": "NP"
            },
            {
                "name": "Netherlands",
                "code": "NL"
            },
            {
                "name": "Netherlands Antilles",
                "code": "AN"
            },
            {
                "name": "New Caledonia",
                "code": "NC"
            },
            {
                "name": "New Zealand",
                "code": "NZ"
            },
            {
                "name": "Nicaragua",
                "code": "NI"
            },
            {
                "name": "Niger",
                "code": "NE"
            },
            {
                "name": "Nigeria",
                "code": "NG"
            },
            {
                "name": "Niue",
                "code": "NU"
            },
            {
                "name": "Norfolk Island",
                "code": "NF"
            },
            {
                "name": "Northern Mariana Islands",
                "code": "MP"
            },
            {
                "name": "Norway",
                "code": "NO"
            },
            {
                "name": "Oman",
                "code": "OM"
            },
            {
                "name": "Pakistan",
                "code": "PK"
            },
            {
                "name": "Palau",
                "code": "PW"
            },
            {
                "name": "Palestinian Territory, Occupied",
                "code": "PS"
            },
            {
                "name": "Panama",
                "code": "PA"
            },
            {
                "name": "Papua New Guinea",
                "code": "PG"
            },
            {
                "name": "Paraguay",
                "code": "PY"
            },
            {
                "name": "Peru",
                "code": "PE"
            },
            {
                "name": "Philippines",
                "code": "PH"
            },
            {
                "name": "Pitcairn",
                "code": "PN"
            },
            {
                "name": "Poland",
                "code": "PL"
            },
            {
                "name": "Portugal",
                "code": "PT"
            },
            {
                "name": "Puerto Rico",
                "code": "PR"
            },
            {
                "name": "Qatar",
                "code": "QA"
            },
            {
                "name": "Reunion",
                "code": "RE"
            },
            {
                "name": "Romania",
                "code": "RO"
            },
            {
                "name": "Russian Federation",
                "code": "RU"
            },
            {
                "name": "RWANDA",
                "code": "RW"
            },
            {
                "name": "Saint Helena",
                "code": "SH"
            },
            {
                "name": "Saint Kitts and Nevis",
                "code": "KN"
            },
            {
                "name": "Saint Lucia",
                "code": "LC"
            },
            {
                "name": "Saint Pierre and Miquelon",
                "code": "PM"
            },
            {
                "name": "Saint Vincent and the Grenadines",
                "code": "VC"
            },
            {
                "name": "Samoa",
                "code": "WS"
            },
            {
                "name": "San Marino",
                "code": "SM"
            },
            {
                "name": "Sao Tome and Principe",
                "code": "ST"
            },
            {
                "name": "Saudi Arabia",
                "code": "SA"
            },
            {
                "name": "Senegal",
                "code": "SN"
            },
            {
                "name": "Serbia and Montenegro",
                "code": "CS"
            },
            {
                "name": "Seychelles",
                "code": "SC"
            },
            {
                "name": "Sierra Leone",
                "code": "SL"
            },
            {
                "name": "Singapore",
                "code": "SG"
            },
            {
                "name": "Slovakia",
                "code": "SK"
            },
            {
                "name": "Slovenia",
                "code": "SI"
            },
            {
                "name": "Solomon Islands",
                "code": "SB"
            },
            {
                "name": "Somalia",
                "code": "SO"
            },
            {
                "name": "South Africa",
                "code": "ZA"
            },
            {
                "name": "South Georgia and the South Sandwich Islands",
                "code": "GS"
            },
            {
                "name": "Spain",
                "code": "ES"
            },
            {
                "name": "Sri Lanka",
                "code": "LK"
            },
            {
                "name": "Sudan",
                "code": "SD"
            },
            {
                "name": "Suriname",
                "code": "SR"
            },
            {
                "name": "Svalbard and Jan Mayen",
                "code": "SJ"
            },
            {
                "name": "Swaziland",
                "code": "SZ"
            },
            {
                "name": "Sweden",
                "code": "SE"
            },
            {
                "name": "Switzerland",
                "code": "CH"
            },
            {
                "name": "Syrian Arab Republic",
                "code": "SY"
            },
            {
                "name": "Taiwan, Province of China",
                "code": "TW"
            },
            {
                "name": "Tajikistan",
                "code": "TJ"
            },
            {
                "name": "Tanzania, United Republic of",
                "code": "TZ"
            },
            {
                "name": "Thailand",
                "code": "TH"
            },
            {
                "name": "Timor-Leste",
                "code": "TL"
            },
            {
                "name": "Togo",
                "code": "TG"
            },
            {
                "name": "Tokelau",
                "code": "TK"
            },
            {
                "name": "Tonga",
                "code": "TO"
            },
            {
                "name": "Trinidad and Tobago",
                "code": "TT"
            },
            {
                "name": "Tunisia",
                "code": "TN"
            },
            {
                "name": "Turkey",
                "code": "TR"
            },
            {
                "name": "Turkmenistan",
                "code": "TM"
            },
            {
                "name": "Turks and Caicos Islands",
                "code": "TC"
            },
            {
                "name": "Tuvalu",
                "code": "TV"
            },
            {
                "name": "Uganda",
                "code": "UG"
            },
            {
                "name": "Ukraine",
                "code": "UA"
            },
            {
                "name": "United Arab Emirates",
                "code": "AE"
            },
            {
                "name": "United Kingdom",
                "code": "GB"
            },
            {
                "name": "United States",
                "code": "US"
            },
            {
                "name": "United States Minor Outlying Islands",
                "code": "UM"
            },
            {
                "name": "Uruguay",
                "code": "UY"
            },
            {
                "name": "Uzbekistan",
                "code": "UZ"
            },
            {
                "name": "Vanuatu",
                "code": "VU"
            },
            {
                "name": "Venezuela",
                "code": "VE"
            },
            {
                "name": "Viet Nam",
                "code": "VN"
            },
            {
                "name": "Virgin Islands, British",
                "code": "VG"
            },
            {
                "name": "Virgin Islands, U.S.",
                "code": "VI"
            },
            {
                "name": "Wallis and Futuna",
                "code": "WF"
            },
            {
                "name": "Western Sahara",
                "code": "EH"
            },
            {
                "name": "Yemen",
                "code": "YE"
            },
            {
                "name": "Zambia",
                "code": "ZM"
            },
            {
                "name": "Zimbabwe",
                "code": "ZW"
            }
        ];
        this.ages = [1, 2, 3, 4, 5, 6, 7, 8, 9,
            10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
            20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
            30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
            40, 41, 42, 43, 44, 45, 46, 47, 48, 49,
            50, 51, 52, 53, 54, 55, 56, 57, 58, 59,
            60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
            70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
            80, 81, 82, 83, 84, 85, 86, 87, 88, 89,
            90, 91, 92, 93, 94, 95, 96, 97, 98, 99,
            100];
    }
    DemographicsPage.prototype.ngOnInit = function () {
        return __awaiter(this, void 0, void 0, function () {
            var headers;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.userData.getUsername().then(function (username) {
                            console.log(username);
                            _this.email = username;
                        })];
                    case 1:
                        _a.sent();
                        headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]();
                        headers.set('Content-Type', 'application/json');
                        this.http.get('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/get_user_info?email=' + this.email, { headers: headers }).subscribe(function (data) {
                            console.log(data);
                            if (data['result'] == 'success') {
                                _this.selected_age = data['user'].age;
                                _this.selected_country = data['user'].country_birth;
                                _this.selected_residence_country = data['user'].country_residence;
                                _this.gender = data['user'].gender;
                            }
                            else {
                                _this.alertshow("Server connection error");
                            }
                        }, function (error) {
                            console.log(error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    DemographicsPage.prototype.save = function () {
        var _this = this;
        this.demographics = {
            "email": this.email,
            "country_birth": this.selected_country,
            "country_residence": this.selected_residence_country,
            "gender": this.gender,
            "age": this.selected_age
        };
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]();
        headers.set('Content-Type', 'application/json');
        this.http.post('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/update_demographics', this.demographics, { headers: headers }).subscribe(function (data) {
            console.log(data);
            if (data['result'] == 'success') {
                // this.router.navigateByUrl("tab/(question:question)")
                _this.alertshow("updated successfully");
            }
            else {
                _this.alertshow("Already username or email exist");
            }
        }, function (error) {
            console.log(error);
        });
    };
    DemographicsPage.prototype.alertshow = function (msg) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: msg,
                            buttons: [
                                {
                                    text: 'Ok',
                                    handler: function (data) { }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    DemographicsPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-demographics',
            template: __webpack_require__(/*! ./demographics.page.html */ "./src/app/settings/demographics/demographics.page.html"),
            styles: [__webpack_require__(/*! ./demographics.page.scss */ "./src/app/settings/demographics/demographics.page.scss")],
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _provider_user_data_service__WEBPACK_IMPORTED_MODULE_4__["UserDataService"]])
    ], DemographicsPage);
    return DemographicsPage;
}());



/***/ }),

/***/ "./src/app/settings/notification/notification.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/settings/notification/notification.module.ts ***!
  \**************************************************************/
/*! exports provided: NotificationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationPageModule", function() { return NotificationPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _notification_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./notification.page */ "./src/app/settings/notification/notification.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _notification_page__WEBPACK_IMPORTED_MODULE_5__["NotificationPage"]
    }
];
var NotificationPageModule = /** @class */ (function () {
    function NotificationPageModule() {
    }
    NotificationPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_notification_page__WEBPACK_IMPORTED_MODULE_5__["NotificationPage"]]
        })
    ], NotificationPageModule);
    return NotificationPageModule;
}());



/***/ }),

/***/ "./src/app/settings/notification/notification.page.html":
/*!**************************************************************!*\
  !*** ./src/app/settings/notification/notification.page.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n    <div padding>\n        <div padding text-center item-text style=\"display: flex;  justify-content: center;  align-items: center; padding-top: 15px\">\n          <div style=\"display: grid; text-align: right\">  \n            <ion-label class=\"title\">Settings</ion-label>\n            <ion-label >Notification</ion-label>\n          </div>\n            <ion-icon class=\"title_icon\" name=\"md-settings\"></ion-icon>\n        </div>\n    </div>\n\n    <div>\n      <div padding>\n        <ion-item expand=\"block\" >\n            <ion-label>WITH NOTIFICATION</ion-label>\n            <ion-select [(ngModel)]=\"notification_action\" class=\"ion_select_color\">\n                <ion-select-option value=\"enable\">YES</ion-select-option>\n                <ion-select-option value=\"disable\">NO</ion-select-option>\n            </ion-select>\n        </ion-item>\n\n        <ion-item  *ngIf=\"notification_action==='enable'\" expand=\"block\" >\n          <ion-label>NOTIFICATION SETTING</ion-label>\n          <ion-select [(ngModel)]=\"notification_type\" class=\"ion_select_color\">\n              <ion-select-option value=\"casual\">CASUAL</ion-select-option>\n              <ion-select-option value=\"custom\">CUSTOM</ion-select-option>\n          </ion-select>\n        </ion-item>\n\n        <ion-item  expand=\"block\" >\n          <ion-label>SELECT A BATCH SIZE</ion-label>\n          <ion-select [(ngModel)]=\"batch_size\" class=\"ion_select_color\">\n              <ion-select-option value=30>30</ion-select-option>\n              <ion-select-option value=50>50</ion-select-option>\n              <ion-select-option value=70>70</ion-select-option>\n          </ion-select>\n        </ion-item>\n\n        <ion-item  *ngIf=\"notification_type==='custom'&&notification_action==='enable'\" expand=\"block\">\n          <ion-label>SELECT A FREQUENCY</ion-label>\n          <ion-select [(ngModel)]=\"frequency\" class=\"ion_select_color\">\n              <ion-select-option value=1>1</ion-select-option>\n              <ion-select-option value=2>2</ion-select-option>\n              <ion-select-option value=3>3</ion-select-option>\n              <ion-select-option value=4>4</ion-select-option>\n              <ion-select-option value=5>5</ion-select-option>\n              <ion-select-option value=6>6</ion-select-option>\n              <ion-select-option value=7>7</ion-select-option>\n              <ion-select-option value=8>8</ion-select-option>\n          </ion-select>\n        </ion-item>\n\n        <ion-item  *ngIf=\"notification_type==='custom'&&notification_action==='enable'\" expand=\"block\" >\n          <ion-label>SELECT START TIME OF DAY</ion-label>\n          <ion-datetime displayFormat=\"HH:mm A\" [(ngModel)]=\"start_time\"></ion-datetime>\n        </ion-item>\n\n        <ion-item  *ngIf=\"notification_type==='custom'&&notification_action==='enable'\" expand=\"block\" >\n          <ion-label>SELECT END TIME OF DAY</ion-label>\n          <ion-datetime displayFormat=\"HH:mm A\" [(ngModel)]=\"end_time\" [value]=\"end_time\"></ion-datetime>\n        </ion-item>\n      </div>\n      \n      <div padding>\n        <ion-button (click)= \"save()\" size=\"default\" expand=\"block\" >SAVE</ion-button>\n      </div>\n    </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/settings/notification/notification.page.scss":
/*!**************************************************************!*\
  !*** ./src/app/settings/notification/notification.page.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-item {\n  --ion-color-shade: #fafafa !important; }\n\nion-select {\n  color: white; }\n\nion-label {\n  font-size: 16px;\n  font-weight: bold; }\n"

/***/ }),

/***/ "./src/app/settings/notification/notification.page.ts":
/*!************************************************************!*\
  !*** ./src/app/settings/notification/notification.page.ts ***!
  \************************************************************/
/*! exports provided: NotificationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationPage", function() { return NotificationPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../provider/user-data.service */ "./src/app/provider/user-data.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var NotificationPage = /** @class */ (function () {
    function NotificationPage(router, http, navCtrl, userData, alertCtrl) {
        this.router = router;
        this.http = http;
        this.navCtrl = navCtrl;
        this.userData = userData;
        this.alertCtrl = alertCtrl;
    }
    NotificationPage.prototype.ngOnInit = function () {
        this.getUsername();
    };
    NotificationPage.prototype.getUsername = function () {
        return __awaiter(this, void 0, void 0, function () {
            var headers;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.userData.getUsername().then(function (username) {
                            console.log(username);
                            _this.email = username;
                        })];
                    case 1:
                        _a.sent();
                        headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
                        headers.set('Content-Type', 'application/json');
                        this.http.get('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/get_user_info?email=' + this.email, { headers: headers }).subscribe(function (data) {
                            console.log(data);
                            if (data['result'] == 'success') {
                                _this.notification_action = data['user'].notification_action;
                                _this.notification_type = data['user'].notification_type;
                                _this.batch_size = data['user'].batch_size;
                                _this.frequency = data['user'].frequency;
                                _this.start_time = data['user'].start_time;
                                _this.end_time = data['user'].end_time;
                            }
                            else {
                                _this.alertshow("Server connection error");
                            }
                        }, function (error) {
                            console.log(error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    NotificationPage.prototype.save = function () {
        var _this = this;
        this.notification = {
            "email": this.email,
            "notification_action": this.notification_action,
            "notification_type": this.notification_type,
            "batch_size": this.batch_size,
            "frequency": this.frequency,
            "start_time": this.start_time,
            "end_time": this.end_time
        };
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
        this.http.post('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/update_notification_setting', this.notification, { headers: headers }).subscribe(function (data) {
            console.log(data);
            if (data['result'] == 'success') {
                _this.userData.setbatch_size(data['updated_user'].batch_size);
                _this.userData.set_start_time(data['updated_user'].start_time);
                _this.userData.set_end_time(data['updated_user'].end_time);
                _this.alertshow("succssfully");
            }
            else {
                _this.alertshow("Already username or email exist");
            }
        }, function (error) {
            console.log(error);
        });
    };
    NotificationPage.prototype.alertshow = function (msg) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: msg,
                            buttons: [
                                {
                                    text: 'Ok',
                                    handler: function (data) { }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NotificationPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-notification',
            template: __webpack_require__(/*! ./notification.page.html */ "./src/app/settings/notification/notification.page.html"),
            styles: [__webpack_require__(/*! ./notification.page.scss */ "./src/app/settings/notification/notification.page.scss")],
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__["UserDataService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], NotificationPage);
    return NotificationPage;
}());



/***/ }),

/***/ "./src/app/settings/settings.module.ts":
/*!*********************************************!*\
  !*** ./src/app/settings/settings.module.ts ***!
  \*********************************************/
/*! exports provided: SettingsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPageModule", function() { return SettingsPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./settings.page */ "./src/app/settings/settings.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _settings_page__WEBPACK_IMPORTED_MODULE_5__["SettingsPage"]
    }
];
var SettingsPageModule = /** @class */ (function () {
    function SettingsPageModule() {
    }
    SettingsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_settings_page__WEBPACK_IMPORTED_MODULE_5__["SettingsPage"]]
        })
    ], SettingsPageModule);
    return SettingsPageModule;
}());



/***/ }),

/***/ "./src/app/settings/settings.page.html":
/*!*********************************************!*\
  !*** ./src/app/settings/settings.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-content padding>\n  <div padding text-center item-text style=\"display: flex;  justify-content: center;  align-items: center; padding-top: 15px\">\n      <!-- <ion-label style=\"font-size: 30px; color: white; font-weight: bold;\">Settings </ion-label> -->\n      <ion-label class=\"title\">Settings </ion-label>\n      <ion-icon class=\"title_icon\" name=\"md-settings\"></ion-icon>\n  </div>\n\n    <div padding>\n        <ion-button size=\"default\" href=\"/tab/(settings:notification)\" expand=\"block\"  >NOTIFICATION</ion-button>\n   \n        <ion-button size=\"default\" href=\"/tab/(settings:demographics)\" expand=\"block\"  >DEMOGRAPHICS</ion-button>\n    </div>\n\n    <div padding>\n        <ion-segment [(ngModel)]=\"swipe\">\n            <ion-segment-button value=\"enable\">\n                <ion-label>ENABLE SWIPE</ion-label>\n            </ion-segment-button>\n            \n            <ion-segment-button value=\"disable\">\n                <ion-label>ENABLE BUTTON</ion-label>\n            </ion-segment-button>\n        </ion-segment>\n    </div>\n    <div padding>\n        <ion-segment [(ngModel)]=\"theme_action\">\n            <ion-segment-button value=\"static\">\n                <ion-label>STATIC THEME</ion-label>\n            </ion-segment-button>\n            \n            <ion-segment-button value=\"dynamic\">\n                <ion-label>DYNAMIC THEME</ion-label>\n            </ion-segment-button>\n        </ion-segment>\n    </div>\n\n    <div padding>\n        <ion-segment [(ngModel)]=\"theme_color\">\n            <ion-segment-button value=\"light\">\n                <ion-label>LIGHT THEME</ion-label>\n            </ion-segment-button>\n            \n            <ion-segment-button value=\"dark\">\n                <ion-label>DARK THEME</ion-label>\n            </ion-segment-button>\n        </ion-segment>\n    </div>\n\n    <div padding>\n        <ion-button size=\"default\" expand=\"block\" (click)=\"save()\">SAVE</ion-button>\n    </div>\n\n    <div padding>\n        <ion-button size=\"default\" expand=\"block\" (click)=\"signout()\">SIGN OUT</ion-button>\n    </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/settings/settings.page.scss":
/*!*********************************************!*\
  !*** ./src/app/settings/settings.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-segment-button {\n  font-size: unset;\n  --border-radius: 10px; }\n\nion-segment {\n  --background-checked: #fafafa;\n  --color: #fafafa;\n  --color-checked: #2B2A2F;\n  --border-color-checked: #fafafa;\n  font-size: 12px;\n  font-weight: bold; }\n\nion-item {\n  --inner-border-width: 0;\n  --border-width: 0 0 1px 0;\n  --border-color: red;\n  border-color: red;\n  --ion-color-shade: #f2f2f2 !important; }\n"

/***/ }),

/***/ "./src/app/settings/settings.page.ts":
/*!*******************************************!*\
  !*** ./src/app/settings/settings.page.ts ***!
  \*******************************************/
/*! exports provided: SettingsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPage", function() { return SettingsPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/user-data.service */ "./src/app/provider/user-data.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var SettingsPage = /** @class */ (function () {
    function SettingsPage(router, http, navCtrl, userData, events, alertCtrl) {
        this.router = router;
        this.http = http;
        this.navCtrl = navCtrl;
        this.userData = userData;
        this.events = events;
        this.alertCtrl = alertCtrl;
        this.swipe = "";
        this.theme_action = "";
        this.theme_color = "";
    }
    SettingsPage.prototype.ngOnInit = function () {
        this.getUsername();
    };
    SettingsPage.prototype.getUsername = function () {
        return __awaiter(this, void 0, void 0, function () {
            var headers;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.userData.getUsername().then(function (username) {
                            console.log(username);
                            _this.email = username;
                        })];
                    case 1:
                        _a.sent();
                        headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
                        headers.set('Content-Type', 'application/json');
                        this.http.get('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/get_user_info?email=' + this.email, { headers: headers }).subscribe(function (data) {
                            console.log(data);
                            if (data['result'] == 'success') {
                                _this.swipe = data['user'].swipe;
                                _this.theme_action = data['user'].theme_action;
                                _this.theme_color = data['user'].theme_color;
                                if (_this.theme_action == "static") {
                                    _this.events.publish('user:theme_color', data['user'].theme_color);
                                }
                            }
                            else {
                                _this.alertshow("Server connection error");
                            }
                        }, function (error) {
                            console.log(error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    SettingsPage.prototype.save = function () {
        var _this = this;
        this.setting = {
            "email": this.email,
            "swipe": this.swipe,
            "theme_action": this.theme_action,
            "theme_color": this.theme_color
        };
        this.now = new Date();
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
        headers.set('Content-Type', 'application/json');
        this.http.post('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/update_theme_setting', this.setting, { headers: headers }).subscribe(function (data) {
            console.log(data);
            if (data['result'] == 'success') {
                _this.swipe = data['user'].swipe;
                _this.theme_action = data['user'].theme_action;
                _this.theme_color = data['user'].theme_color;
                // this.events.publish('user:theme_color', this.theme_color);
                if (_this.theme_action == "static") {
                    _this.events.publish('user:theme_color', data['user'].theme_color);
                }
                else {
                    if (_this.now.getHours() > 18) {
                        // console.log("evening");
                        if (_this.theme_color == 'light') {
                            _this.events.publish('user:theme_color', "dark");
                        }
                    }
                    else {
                        // console.log("afternoon"); 
                        if (_this.theme_color == 'dark') {
                            _this.events.publish('user:theme_color', "light");
                        }
                    }
                }
                _this.events.publish('swipe', _this.swipe);
            }
            else {
                _this.alertshow("Server connection error");
            }
        }, function (error) {
            console.log(error);
        });
    };
    SettingsPage.prototype.alertshow = function (msg) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: msg,
                            buttons: [
                                {
                                    text: 'Ok',
                                    handler: function (data) { }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    SettingsPage.prototype.signout = function () {
        this.router.navigateByUrl("/loginpage");
    };
    SettingsPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-settings',
            template: __webpack_require__(/*! ./settings.page.html */ "./src/app/settings/settings.page.html"),
            styles: [__webpack_require__(/*! ./settings.page.scss */ "./src/app/settings/settings.page.scss")],
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _provider_user_data_service__WEBPACK_IMPORTED_MODULE_3__["UserDataService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Events"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], SettingsPage);
    return SettingsPage;
}());



/***/ }),

/***/ "./src/app/tab/tab.module.ts":
/*!***********************************!*\
  !*** ./src/app/tab/tab.module.ts ***!
  \***********************************/
/*! exports provided: TabPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabPageModule", function() { return TabPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _tab_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tab.page */ "./src/app/tab/tab.page.ts");
/* harmony import */ var _question_question_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../question/question.module */ "./src/app/question/question.module.ts");
/* harmony import */ var _profile_profile_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../profile/profile.module */ "./src/app/profile/profile.module.ts");
/* harmony import */ var _permissions_permissions_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../permissions/permissions.module */ "./src/app/permissions/permissions.module.ts");
/* harmony import */ var _comparison_comparison_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../comparison/comparison.module */ "./src/app/comparison/comparison.module.ts");
/* harmony import */ var _settings_settings_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../settings/settings.module */ "./src/app/settings/settings.module.ts");
/* harmony import */ var _permissions_addpermission_addpermission_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../permissions/addpermission/addpermission.module */ "./src/app/permissions/addpermission/addpermission.module.ts");
/* harmony import */ var _permissions_revokepermission_revokepermission_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../permissions/revokepermission/revokepermission.module */ "./src/app/permissions/revokepermission/revokepermission.module.ts");
/* harmony import */ var _permissions_permissioncode_permissioncode_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../permissions/permissioncode/permissioncode.module */ "./src/app/permissions/permissioncode/permissioncode.module.ts");
/* harmony import */ var _comparison_usercomparison_usercomparison_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../comparison/usercomparison/usercomparison.module */ "./src/app/comparison/usercomparison/usercomparison.module.ts");
/* harmony import */ var _settings_notification_notification_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../settings/notification/notification.module */ "./src/app/settings/notification/notification.module.ts");
/* harmony import */ var _settings_demographics_demographics_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../settings/demographics/demographics.module */ "./src/app/settings/demographics/demographics.module.ts");
/* harmony import */ var _question_question_page__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../question/question.page */ "./src/app/question/question.page.ts");
/* harmony import */ var _profile_profile_page__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../profile/profile.page */ "./src/app/profile/profile.page.ts");
/* harmony import */ var _permissions_permissions_page__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../permissions/permissions.page */ "./src/app/permissions/permissions.page.ts");
/* harmony import */ var _settings_settings_page__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../settings/settings.page */ "./src/app/settings/settings.page.ts");
/* harmony import */ var _comparison_comparison_page__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../comparison/comparison.page */ "./src/app/comparison/comparison.page.ts");
/* harmony import */ var _permissions_addpermission_addpermission_page__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../permissions/addpermission/addpermission.page */ "./src/app/permissions/addpermission/addpermission.page.ts");
/* harmony import */ var _permissions_revokepermission_revokepermission_page__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../permissions/revokepermission/revokepermission.page */ "./src/app/permissions/revokepermission/revokepermission.page.ts");
/* harmony import */ var _permissions_permissioncode_permissioncode_page__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../permissions/permissioncode/permissioncode.page */ "./src/app/permissions/permissioncode/permissioncode.page.ts");
/* harmony import */ var _comparison_usercomparison_usercomparison_page__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../comparison/usercomparison/usercomparison.page */ "./src/app/comparison/usercomparison/usercomparison.page.ts");
/* harmony import */ var _settings_demographics_demographics_page__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../settings/demographics/demographics.page */ "./src/app/settings/demographics/demographics.page.ts");
/* harmony import */ var _settings_notification_notification_page__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../settings/notification/notification.page */ "./src/app/settings/notification/notification.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




























var routes = [
    {
        path: 'tab',
        component: _tab_page__WEBPACK_IMPORTED_MODULE_5__["TabPage"],
        children: [
            {
                path: 'question',
                outlet: 'question',
                component: _question_question_page__WEBPACK_IMPORTED_MODULE_17__["QuestionPage"],
            },
            {
                path: 'profile',
                outlet: 'profile',
                component: _profile_profile_page__WEBPACK_IMPORTED_MODULE_18__["ProfilePage"],
            },
            {
                path: 'permissions',
                outlet: 'permissions',
                component: _permissions_permissions_page__WEBPACK_IMPORTED_MODULE_19__["PermissionsPage"],
            },
            {
                path: 'addpermission',
                outlet: 'permissions',
                component: _permissions_addpermission_addpermission_page__WEBPACK_IMPORTED_MODULE_22__["AddpermissionPage"],
            },
            {
                path: 'revokepermission',
                outlet: 'permissions',
                component: _permissions_revokepermission_revokepermission_page__WEBPACK_IMPORTED_MODULE_23__["RevokepermissionPage"],
            },
            {
                path: 'permissioncode',
                outlet: 'permissions',
                component: _permissions_permissioncode_permissioncode_page__WEBPACK_IMPORTED_MODULE_24__["PermissioncodePage"],
            },
            {
                path: 'comparison',
                outlet: 'comparison',
                component: _comparison_comparison_page__WEBPACK_IMPORTED_MODULE_21__["ComparisonPage"],
            },
            {
                path: 'usercomparison/:index',
                outlet: 'comparison',
                component: _comparison_usercomparison_usercomparison_page__WEBPACK_IMPORTED_MODULE_25__["UsercomparisonPage"],
            },
            {
                path: 'settings',
                outlet: 'settings',
                component: _settings_settings_page__WEBPACK_IMPORTED_MODULE_20__["SettingsPage"],
            },
            {
                path: 'notification',
                outlet: 'settings',
                component: _settings_notification_notification_page__WEBPACK_IMPORTED_MODULE_27__["NotificationPage"],
            },
            {
                path: 'demographics',
                outlet: 'settings',
                component: _settings_demographics_demographics_page__WEBPACK_IMPORTED_MODULE_26__["DemographicsPage"],
            },
        ]
    },
    {
        path: '',
        redirectTo: '/tab/(question:question)',
        pathMatch: 'full'
    }
];
var TabPageModule = /** @class */ (function () {
    function TabPageModule() {
    }
    TabPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _question_question_module__WEBPACK_IMPORTED_MODULE_6__["QuestionPageModule"],
                _profile_profile_module__WEBPACK_IMPORTED_MODULE_7__["ProfilePageModule"],
                _permissions_permissions_module__WEBPACK_IMPORTED_MODULE_8__["PermissionsPageModule"],
                _comparison_comparison_module__WEBPACK_IMPORTED_MODULE_9__["ComparisonPageModule"],
                _settings_settings_module__WEBPACK_IMPORTED_MODULE_10__["SettingsPageModule"],
                _permissions_addpermission_addpermission_module__WEBPACK_IMPORTED_MODULE_11__["AddpermissionPageModule"],
                _permissions_revokepermission_revokepermission_module__WEBPACK_IMPORTED_MODULE_12__["RevokepermissionPageModule"],
                _permissions_permissioncode_permissioncode_module__WEBPACK_IMPORTED_MODULE_13__["PermissioncodePageModule"],
                _comparison_usercomparison_usercomparison_module__WEBPACK_IMPORTED_MODULE_14__["UsercomparisonPageModule"],
                _settings_notification_notification_module__WEBPACK_IMPORTED_MODULE_15__["NotificationPageModule"],
                _settings_demographics_demographics_module__WEBPACK_IMPORTED_MODULE_16__["DemographicsPageModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes),
            ],
            declarations: [_tab_page__WEBPACK_IMPORTED_MODULE_5__["TabPage"]],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"]]
        })
    ], TabPageModule);
    return TabPageModule;
}());



/***/ }),

/***/ "./src/app/tab/tab.page.html":
/*!***********************************!*\
  !*** ./src/app/tab/tab.page.html ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-tabs (ionChange)=\"eventTest()\">\n  <ion-tab-bar slot=\"bottom\" >\n    <ion-tab-button tab=\"question\" href=\"/tab/(question:question)\">\n      <ion-icon name=\"md-help\"></ion-icon>\n      <ion-label>Questions</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"profile\" href=\"/tab/(profile:profile)\">\n      <ion-icon name=\"md-person\"></ion-icon>\n      <ion-label>Profile</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"permissions\" href=\"/tab/(permissions:permissions)\">\n      <ion-icon name=\"md-lock\"></ion-icon>\n      <ion-label>Permission</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"comparison\" href=\"/tab/(comparison:comparison)\">\n      <ion-icon name=\"md-text\"></ion-icon>\n      <ion-label>Comparison</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"settings\" href=\"/tab/(settings:settings)\">\n      <ion-icon name=\"md-settings\"></ion-icon>\n      <ion-label>Setting</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n\n  <ion-tab tab=\"questions\">\n    <ion-router-outlet name=\"question\"></ion-router-outlet>\n  </ion-tab>\n\n  <ion-tab tab=\"profile\">\n    <ion-router-outlet name=\"profile\"></ion-router-outlet>\n  </ion-tab>\n\n  <ion-tab tab=\"permissions\">\n    <ion-router-outlet name=\"permissions\"></ion-router-outlet>\n  </ion-tab>\n\n  <ion-tab tab=\"comparison\">\n    <ion-router-outlet name=\"comparison\"></ion-router-outlet>\n  </ion-tab>\n\n  <ion-tab tab=\"settings\">\n    <ion-router-outlet name=\"settings\"></ion-router-outlet>\n  </ion-tab>\n\n</ion-tabs>\n\n<!-- <ion-tabs>\n  <ion-tab label=\"Question\" icon=\"text\" href=\"/tab/(question:question)\">\n    <ion-router-outlet name=\"question\"></ion-router-outlet>\n  </ion-tab>\n  <ion-tab label=\"Profile\" icon=\"contact\" href=\"/tab/(profile:profile)\">\n    <ion-router-outlet name=\"profile\"></ion-router-outlet>\n  </ion-tab>\n  <ion-tab label=\"Permission\" icon=\"unlock\" href=\"/tab/(permission:permission)\">\n    <ion-router-outlet name=\"permission\"></ion-router-outlet>\n  </ion-tab>\n  <ion-tab label=\"Comparison\" icon=\"people\" href=\"/tab/(comparison:comparison)\">\n    <ion-router-outlet name=\"comparison\"></ion-router-outlet>\n  </ion-tab>\n  <ion-tab label=\"Settings\" icon=\"md-settings\" href=\"/tab/(settings:settings)\">\n    <ion-router-outlet name=\"settings\"></ion-router-outlet>\n  </ion-tab>\n</ion-tabs>\n -->\n"

/***/ }),

/***/ "./src/app/tab/tab.page.scss":
/*!***********************************!*\
  !*** ./src/app/tab/tab.page.scss ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-tab-button {\n  --color: #C2F5FE;\n  --color-selected: white; }\n"

/***/ }),

/***/ "./src/app/tab/tab.page.ts":
/*!*********************************!*\
  !*** ./src/app/tab/tab.page.ts ***!
  \*********************************/
/*! exports provided: TabPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabPage", function() { return TabPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _provider_user_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../provider/user-data.service */ "./src/app/provider/user-data.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var TabPage = /** @class */ (function () {
    function TabPage(userData, events, http) {
        this.userData = userData;
        this.events = events;
        this.http = http;
    }
    TabPage.prototype.ngOnInit = function () {
    };
    TabPage.prototype.eventTest = function () {
        return __awaiter(this, void 0, void 0, function () {
            var headers;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.now = new Date();
                        return [4 /*yield*/, this.userData.getUsername().then(function (username) {
                                console.log(username);
                                _this.email = username;
                            })];
                    case 1:
                        _a.sent();
                        headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]();
                        headers.set('Content-Type', 'application/json');
                        this.http.get('https://cors-anywhere.herokuapp.com/http://www.deepperson.net/api/get_user_info?email=' + this.email, { headers: headers }).subscribe(function (data) {
                            console.log(data);
                            if (data['result'] == 'success') {
                                _this.theme_action = data['user'].theme_action;
                                _this.theme_color = data['user'].theme_color;
                            }
                            else {
                            }
                        }, function (error) {
                            console.log(error);
                        });
                        if (this.theme_action == 'dynamic') {
                            if (this.now.getHours() > 18) {
                                // console.log("evening");
                                if (this.theme_color == 'light') {
                                    this.events.publish('user:theme_color', "dark");
                                }
                            }
                            else {
                                // console.log("afternoon"); 
                                if (this.theme_color == 'dark') {
                                    this.events.publish('user:theme_color', "light");
                                }
                            }
                        }
                        else { }
                        return [2 /*return*/];
                }
            });
        });
    };
    TabPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-tab',
            template: __webpack_require__(/*! ./tab.page.html */ "./src/app/tab/tab.page.html"),
            styles: [__webpack_require__(/*! ./tab.page.scss */ "./src/app/tab/tab.page.scss")],
        }),
        __metadata("design:paramtypes", [_provider_user_data_service__WEBPACK_IMPORTED_MODULE_1__["UserDataService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Events"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]])
    ], TabPage);
    return TabPage;
}());



/***/ })

}]);
//# sourceMappingURL=tab-tab-module.js.map