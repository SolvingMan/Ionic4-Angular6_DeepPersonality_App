(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["index-login-module"],{

/***/ "./src/app/index/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/index/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login.page */ "./src/app/index/login.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_5__["LoginPage"]
    }
];
var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_login_page__WEBPACK_IMPORTED_MODULE_5__["LoginPage"]]
        })
    ], LoginPageModule);
    return LoginPageModule;
}());



/***/ }),

/***/ "./src/app/index/login.page.html":
/*!***************************************!*\
  !*** ./src/app/index/login.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n\n<ion-content padding >\n  <div class=\"body\">\n    <div class=\"contain\">\n      <ion-img  src=\"/assets/icon/icon.png\" class=\"background-image\"></ion-img>\n      <h3  style=\"color: #fafafa; font-weight: bold; font-size: 29px\">Deep Personality</h3>\n      <button  class=\"login\"  (click)=\"Login()\">Sign In</button>\n      <button  class=\"signup\" (click)=\"Signup()\">Sign Up</button>\n    </div>\n  </div>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/index/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/index/login.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".body {\n  width: 100%;\n  height: 100%;\n  display: flex !important;\n  justify-content: center !important;\n  justify-items: center !important; }\n  .body .contain {\n    width: 80%;\n    height: 80%;\n    margin: auto;\n    text-align: center; }\n  .body .contain .background-image {\n      width: 30%;\n      height: 100px;\n      -o-object-fit: contain;\n         object-fit: contain;\n      margin: auto;\n      top: 100px; }\n  .body .contain .login {\n      margin-top: 60%;\n      width: 80%;\n      height: 8%;\n      border-radius: 10px;\n      font-size: 20px;\n      font-weight: bold;\n      color: #2B2A2F;\n      background-color: #fafafa;\n      border: solid;\n      border-width: 1px !important;\n      border-color: white !important;\n      outline: unset; }\n  .body .contain .login .login:hover {\n        background-color: white !important; }\n  .body .contain .signup {\n      margin-top: 5%;\n      width: 80%;\n      height: 8%;\n      border-radius: 10px;\n      font-size: 20px;\n      font-weight: bold;\n      color: #fafafa;\n      background-color: #2B2A2F;\n      border: solid;\n      border-width: 1px !important;\n      border-color: #fafafa !important;\n      outline: unset; }\n  ion-content {\n  --ion-background-color: #2B2A2F; }\n  .horizental-center {\n  margin: auto; }\n"

/***/ }),

/***/ "./src/app/index/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/index/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var LoginPage = /** @class */ (function () {
    function LoginPage(router) {
        this.router = router;
    }
    LoginPage.prototype.ngOnInit = function () {
    };
    LoginPage.prototype.Login = function () {
        this.router.navigateByUrl("/loginpage");
    };
    LoginPage.prototype.Signup = function () {
        this.router.navigateByUrl("/signuppage");
    };
    LoginPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.page.html */ "./src/app/index/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/index/login.page.scss")],
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], LoginPage);
    return LoginPage;
}());



/***/ })

}]);
//# sourceMappingURL=index-login-module.js.map